function params = get_params(scenarioOrConfig)
% GET_PARAMS  Shared parameter struct.
%
% FIXES:
%  FIX-1: num_pulses 4→20   N=200 > max_delay=120 → real echo captured
%  FIX-2: forecast_horizon  120→30s → risk ramps gradually
%  FIX-3: eigen_snr disabled → no more 89 dB artifact
%  FIX-4: colored_noise off  → no SNR burst-drops
%  FIX-5: rateAlert/Flood above quantization ceiling (3.13 cm/s)
%  FIX-6: Tsim 120→160s     → alarm has time to confirm after t=80s
%  FIX-7: persistenceWindow 60→30s → confirmation within simulation time
%  FIX-8: cfar_Pfa 1e-4→1e-6, cfar_train_cells 16→32 → sparse detections

    if nargin < 1, scenarioOrConfig = 'slow_rise'; end

    %% --- Time Settings -------------------------------------------
    params.dt   = 1;
    params.Tsim = 160;      % FIX-6: was 120; alert@t=80 + 30s persistence = t=110 ✓

    %% --- Radar Geometry ------------------------------------------
    params.mountHeight     = 15;
    params.samplesPerMeter = 8;

    %% --- Water Level Thresholds (m) ------------------------------
    params.levelAlert = 2.5;
    params.levelFlood = 3.0;

    %% --- Rate of Rise Thresholds (m/s) --------------------------
    % FIX-5: quantization noise ceiling = 0.125m/8s = 0.0156 m/s (2-step)
    %        raised thresholds safely above ceiling
    % FIX: quantized rate for slow_rise (0.025 m/s) alternates 0.0156 / 0.0313 m/s
    %      rateAlert=0.020 → triggers on 0.0313 spikes = correct for rising water
    %      rateFlood=0.040 → only fast_rise (0.08 m/s) triggers = correct
    params.rateAlert = 0.020;    % 2 cm/s  (above 1-step quant 1.56, below 2-step 3.13)
    params.rateFlood = 0.040;    % 4 cm/s  (only fast_rise scenarios)

    %% --- SNR Threshold (dB) -------------------------------------
    params.snrThreshold = 6;

    %% --- Persistence --------------------------------------------
    params.persistenceWindow = 30;   % FIX-7: was 60; 30s ensures confirmation
    params.persistenceCount  = 3;    %         within simulation time

    %% --- Noise / Clutter ----------------------------------------
    params.noiseStdMonitoring = 0.05;
    params.noiseStdAlert      = 0.04;
    params.clutterLevel       = 0.08;
    params.SNR_dB             = 15;
    params.clutter_dB         = -5;
    params.multipath          = true;

    %% --- Waveform -----------------------------------------------
    params.fs                        = 1e4;
    params.pulse_repetition_interval = 1e-3;

    % FIX-1: was 4 → N=40 < delay=120 → no echo → CFAR saw only zeros
    %         extrapolated in range_profile → noise_est=0 → all detections
    % Now 20 → N=200 > 120 → echo arrives → CFAR works correctly
    params.num_pulses = 20;

    params.duty_cycle  = 0.05;
    params.zc_root     = 5;
    params.zc_length   = 127;
    params.chirp_bandwidth = 20e6;
    params.chirp_duration  = 20e-6;

    %% --- Signal-Generation Extras --------------------------------
    params.f0                 = 24e9;
    params.enable_passband    = false;
    params.frequency_agility  = true;
    params.freq_hop_set       = [-1 -0.5 0 0.5 1]*2e3;
    params.window_type        = 'hann';
    params.window_param       = 60;
    params.bursts_per_frame   = 1;
    params.gap_between_bursts = 0;
    params.code_type          = 'none';
    params.barker_length      = 13;
    params.frank_M            = 4;

    %% --- Environment / Propagation -------------------------------
    params.scenario         = 'slow_rise';
    params.wave_spectrum    = 'pierson_moskowitz';
    params.wind_speed_U10   = 6;
    params.enable_doppler   = true;
    params.lambda           = 3e8 / 24e9;
    params.bank_multipath   = true;
    params.bank_offset_m    = 8;

    % FIX-4: AR(1) alpha=0.9 creates correlated noise bursts → SNR drops
    params.colored_noise    = false;
    params.color_alpha      = 0.9;
    params.rain_rate_mmph   = 0;
    params.rain_k           = 0.0001;
    params.rain_alpha_exp   = 1.0;

    %% --- Signal-Processing Extras --------------------------------
    params.enable_range_doppler = true;
    params.cfar_enabled         = true;
    params.cfar_type            = 'CA';
    params.cfar_Pfa             = 1e-6;    % FIX-8: was 1e-4 → too many false alarms
    params.cfar_train_cells     = 32;      % FIX-8: was 16 → better noise estimate
    params.cfar_guard_cells     = 4;
    params.kalman_enabled       = true;
    params.eigen_snr_enabled    = false;   % FIX-3: was true → 89 dB artifact
    params.mti_order            = 2;
    params.super_resolution     = 'none';
    params.sr_num_targets       = 1;

    %% --- Decision-Logic Extras -----------------------------------
    params.forecast_enabled      = true;
    params.forecast_horizon_s    = 30;     % FIX-2: was 120 → instant risk=100%
    params.forecast_history_s    = 30;
    params.ml_classifier_enabled = true;
    params.ml_model_path         = '';

    %% --- Matrix / Storage ----------------------------------------
    params.autosave_mat_file = 'rx_matrix_data.mat';
    params.autosave_enabled  = true;

    %% --- Visualisation -------------------------------------------
    params.use_gui            = false;
    params.show_countdown     = true;
    params.show_risk_curve    = true;
    params.show_range_doppler = true;
    params.export_report      = false;
    params.report_file        = 'flood_report.pdf';
    params.use_3d_fog         = true;
    params.use_big_indicators = true;
    params.use_stl_radar      = false;
    params.stl_radar_file     = 'tower.stl';
    params.use_tabs           = true;
    params.use_topo_map       = false;

    %% --- Monte Carlo ---------------------------------------------
    params.mc_runs      = 0;
    params.mc_seed_base = 42;
    params.weather_file = '';
    params.raytracing   = false;

    %% --- Rate Estimation Window ----------------------------------
    params.rateWindow = params.samplesPerMeter;
    params.dt_rate    = params.samplesPerMeter * params.dt;

    %% --- Scenario overlay ----------------------------------------
    if ischar(scenarioOrConfig) || isstring(scenarioOrConfig)
        params.scenario = char(scenarioOrConfig);
    elseif isstruct(scenarioOrConfig)
        params = mergeStructs(params, scenarioOrConfig);
    end

    switch lower(params.scenario)
        case 'stable',      params.rise_rate = 0.0;
        case 'slow_rise',   params.rise_rate = 0.025;
        case 'fast_rise',   params.rise_rate = 0.08;
        case 'receding',    params.rise_rate = -0.015;
        case 'flash_flood', params.rise_rate = 0.15;
        otherwise,          params.rise_rate = 0.025;
    end

    if isfield(params,'f0') && params.f0 > 0
        params.lambda = 3e8 / params.f0;
    end
end

function a = mergeStructs(a, b)
    if ~isstruct(b), return; end
    fn = fieldnames(b);
    for i = 1:numel(fn)
        k = fn{i};
        if isfield(a,k) && isstruct(a.(k)) && isstruct(b.(k))
            a.(k) = mergeStructs(a.(k), b.(k));
        else
            a.(k) = b.(k);
        end
    end
end
