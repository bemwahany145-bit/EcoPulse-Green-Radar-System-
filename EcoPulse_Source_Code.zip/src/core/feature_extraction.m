function features = feature_extraction(proc, prevLevel, params, meta, kalmanState)
% FEATURE_EXTRACTION  Enhanced feature extraction.
%
%   features = feature_extraction(proc, prevLevel, params, meta, kalmanState)
%
% New:
%   * Kalman-filtered level/rate if params.kalman_enabled
%   * Doppler-derived velocity feature
%   * Peak-width and CFAR target count features
%   * Returns updated Kalman state if requested (5-th output arg)

    if nargin < 4, meta = []; end
    if nargin < 5, kalmanState = []; end

    if ~isstruct(proc), error('proc must be a struct.'); end
    if ~isfield(params,'dt') || ~isfield(params,'snrThreshold')
        error('Missing dt or snrThreshold.');
    end

    % --- Water level & range from ground truth or estimate ---
    if ~isempty(meta) && isfield(meta,'waterLevel') && isfield(meta,'range')
        currentLevel = meta.waterLevel;
        currentRange = meta.range;
    else
        if ~isfield(proc,'estimatedRange')
            error('proc.estimatedRange required if meta is missing.');
        end
        currentRange = proc.estimatedRange;
        currentLevel = max(params.mountHeight - currentRange, 0);
    end

    % --- Kalman filter smoothing (optional) ------------------
    if getfield_or(params,'kalman_enabled',false) && exist('kalman_tracker','file')
        [xEst, kalmanState] = kalman_tracker(currentLevel, params.dt, kalmanState);
        currentLevel_kal = xEst(1);
        rateOfRise_kal   = xEst(2);
    else
        currentLevel_kal = currentLevel;
        rateOfRise_kal   = NaN;
    end

    % --- Raw rate of rise ------------------------------------
    if isempty(prevLevel) || isnan(prevLevel)
        deltaLevel = 0; rateOfRise_raw = 0;
    else
        deltaLevel = currentLevel - prevLevel;
        rateOfRise_raw = deltaLevel / params.dt;
    end

    if ~isnan(rateOfRise_kal)
        rateOfRise = rateOfRise_kal;
    else
        rateOfRise = rateOfRise_raw;
    end

    % --- SNR -------------------------------------------------
    if isfield(proc,'snrEst_dB'), snr = proc.snrEst_dB; else, snr = 0; end
    confidence = double(snr >= params.snrThreshold);

    % --- Trend (simple rule) ---------------------------------
    if rateOfRise > 0.02, trend = "rising";
    elseif rateOfRise < -0.02, trend = "falling";
    else, trend = "stable"; end

    % --- Doppler / surface velocity --------------------------
    if isstruct(meta) && isfield(meta,'surface_vz')
        surfVz = meta.surface_vz;
    else
        surfVz = 0;
    end

    % --- Peak width (3-dB) -----------------------------------
    peakWidth = 0;
    if isfield(proc,'range_profile') && ~isempty(proc.range_profile)
        rp = proc.range_profile;
        [pv,pi] = max(rp);
        if pv>0
            half = pv/sqrt(2);
            l = find(rp(1:pi)<half,1,'last');     if isempty(l), l = 1;        end
            r = find(rp(pi:end)<half,1,'first') + pi - 1; if isempty(r), r = length(rp); end
            peakWidth = (r-l)/params.samplesPerMeter;
        end
    end

    % --- CFAR target count -----------------------------------
    if isfield(proc,'cfar_mask'), cfarTargets = nnz(proc.cfar_mask); else, cfarTargets = 0; end

    % --- Pack ------------------------------------------------
    features = struct();
    features.waterLevel     = currentLevel_kal;
    features.waterLevel_raw = currentLevel;
    features.rateOfRise     = rateOfRise;
    features.rateOfRise_raw = rateOfRise_raw;
    features.deltaLevel     = deltaLevel;
    features.snr            = snr;
    features.confidence     = confidence;
    features.range          = currentRange;
    features.trend          = trend;
    features.surfaceVz      = surfVz;
    features.peakWidth      = peakWidth;
    features.cfarTargets    = cfarTargets;
    features.kalmanState    = kalmanState;   % pass back for caller
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
