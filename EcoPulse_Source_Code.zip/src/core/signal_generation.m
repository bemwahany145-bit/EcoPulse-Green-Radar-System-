function [tx_signal, tx_matrix, meta_tx] = signal_generation(mode, params)
% SIGNAL_GENERATION  Enhanced transmitter waveform generator.
%
% Supports:
%   * Zadoff-Chu (mode 1) and LFM chirp (mode 2)
%   * Optional Barker / Frank phase coding
%   * Selectable window: hann, kaiser, chebwin, taylorwin
%   * Pulse-to-pulse frequency agility (frequency hopping)
%   * Multiple bursts with configurable gaps
%   * Optional passband upconversion to carrier f0
%
% OUTPUT:
%   tx_signal : [N×1] complex baseband (or real passband if requested)
%   tx_matrix : [Lp+Ls × Np] fast-time x slow-time
%   meta_tx   : struct with carrier freq used per pulse, code info, etc.

    if nargin < 2, params = get_params(); end
    if nargin < 1, mode = 1; end

    fs   = params.fs;
    PRI  = params.pulse_repetition_interval;
    Np   = params.num_pulses;
    duty = params.duty_cycle;
    Tp   = duty * PRI;
    Lp   = round(Tp * fs);
    Ls   = round((PRI - Tp) * fs);

    % ---- 1) Build the fundamental baseband pulse -----------
    switch mode
        case 1      % Zadoff-Chu
            N = params.zc_length;
            u = params.zc_root;
            n = (0:N-1)';
            zc = exp(-1j * pi * u * n .* (n+1) / N);
            if N >= Lp
                pulse = zc(1:Lp);
            else
                pulse = [zc; zeros(Lp-N,1)];
            end
            codeInfo = sprintf('Zadoff-Chu N=%d u=%d', N, u);
        otherwise   % LFM chirp (mode 2 or any other value)
            t = (0:Lp-1)' / fs;
            B = params.chirp_bandwidth;
            k = B / Tp;
            pulse = exp(1j*pi*k*t.^2);
            codeInfo = sprintf('LFM B=%.1fMHz Tp=%.1fus', B/1e6, Tp*1e6);
    end

    % ---- 2) Optional phase coding (overrides pulse above) --
    switch lower(params.code_type)
        case 'barker'
            bar = barker_code(params.barker_length);
            pulse = expand_code(bar, Lp);
            codeInfo = [codeInfo sprintf(' + Barker-%d', params.barker_length)];
        case 'frank'
            fr = frank_code(params.frank_M);
            pulse = expand_code(fr, Lp);
            codeInfo = [codeInfo sprintf(' + Frank-%d', params.frank_M^2)];
        otherwise
            % none
    end

    % ---- 3) Apply window ------------------------------------
    win = select_window(params.window_type, Lp, params.window_param);
    pulse = pulse .* win;
    pulse = pulse / max(abs(pulse)+eps);

    % ---- 4) Build pulse train with frequency agility -------
    meta_tx.f_pulse = zeros(Np,1);
    single_pulse = [pulse; zeros(Ls,1)];
    tx_matrix = zeros(Lp+Ls, Np);
    nAxis = (0:Lp+Ls-1)' / fs;
    for m = 1:Np
        if params.frequency_agility
            hopSet = params.freq_hop_set(:);
            df = hopSet(mod(m-1, numel(hopSet)) + 1);
        else
            df = 0;
        end
        meta_tx.f_pulse(m) = df;
        tx_matrix(:,m) = single_pulse .* exp(1j*2*pi*df*nAxis);
    end
    tx_signal = tx_matrix(:);

    % ---- 5) Multi-burst with gaps ---------------------------
    if params.bursts_per_frame > 1
        gap = zeros(round(params.gap_between_bursts*fs),1);
        tx_signal_burst = tx_signal;
        for b = 2:params.bursts_per_frame
            tx_signal = [tx_signal; gap; tx_signal_burst]; %#ok<AGROW>
        end
    end

    % ---- 6) Optional passband upconversion -----------------
    if params.enable_passband && params.f0 > 0
        tAll = (0:length(tx_signal)-1).' / fs;
        tx_signal = real(tx_signal .* exp(1j*2*pi*params.f0*tAll));
    end

    meta_tx.mode    = mode;
    meta_tx.code    = codeInfo;
    meta_tx.window  = params.window_type;
    meta_tx.passband = params.enable_passband;
end

% =========================================================
% Helpers
% =========================================================
function w = select_window(type, L, par)
    % Robust window selector that works on MATLAB and plain Octave
    % (no Signal Processing Toolbox / signal pkg required).
    switch lower(type)
        case 'hann'
            if exist('hann','file'), w = hann(L);
            else, w = safe_hann(L); end
        case 'hamming'
            if exist('hamming','file'), w = hamming(L);
            else, w = safe_hamming(L); end
        case 'kaiser'
            if exist('kaiser','file'), w = kaiser(L, max(par,1));
            else, w = safe_hann(L); end
        case 'chebwin'
            if exist('chebwin','file'), w = chebwin(L, par);
            else, w = safe_hann(L); end
        case 'taylorwin'
            if exist('taylorwin','file'), w = taylorwin(L, 4, -par);
            else, w = safe_hann(L); end
        otherwise,         w = ones(L,1);
    end
    w = w(:);
end

function w = safe_hann(L)
    n = (0:L-1).';
    w = 0.5 - 0.5*cos(2*pi*n / max(L-1,1));
end
function w = safe_hamming(L)
    n = (0:L-1).';
    w = 0.54 - 0.46*cos(2*pi*n / max(L-1,1));
end

function c = barker_code(L)
% Return known Barker sequences (+/-1)
    switch L
        case 2,  c = [1 -1];
        case 3,  c = [1 1 -1];
        case 4,  c = [1 1 -1 1];
        case 5,  c = [1 1 1 -1 1];
        case 7,  c = [1 1 1 -1 -1 1 -1];
        case 11, c = [1 1 1 -1 -1 -1 1 -1 -1 1 -1];
        case 13, c = [1 1 1 1 1 -1 -1 1 1 -1 1 -1 1];
        otherwise
            warning('Barker length %d not standard; using 13.', L);
            c = [1 1 1 1 1 -1 -1 1 1 -1 1 -1 1];
    end
    c = c(:);
end

function c = frank_code(M)
% Frank polyphase code of length M^2
    n = (0:M-1); k = (0:M-1);
    [N,K] = meshgrid(n,k);
    Phi = 2*pi*N.*K/M;
    c = exp(1j*Phi); c = c(:);
end

function out = expand_code(code, L)
% Stretch a discrete code vector across L samples (nearest neighbour)
    idx = min(ceil((1:L)' * numel(code) / L), numel(code));
    out = code(idx);
end
