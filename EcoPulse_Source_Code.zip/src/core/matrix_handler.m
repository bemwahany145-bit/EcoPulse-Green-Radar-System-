function varargout = matrix_handler(command, varargin)
% MATRIX_HANDLER  Enhanced range-profile matrix manager.
%
% Commands:
%   init            : initialise storage with params
%   add             : append a range profile row
%   get_filtered    : return filtered matrix only
%   get_all         : return {filtered, raw}
%   save_mat        : auto-save raw and filtered to .mat file
%   reset           : clear internal state
%
% Enhancements vs original:
%   * Supports higher-order MTI (params.mti_order)
%   * Auto-reshapes when range-bin count changes
%   * Auto-saves at end (params.autosave_enabled)

    persistent raw_matrix current_row max_rows num_range_bins params_saved last_Lpri

    switch lower(command)

        case 'init'
            params_saved = varargin{1};
            max_range = params_saved.mountHeight + 5;
            num_range_bins = round(max_range * params_saved.samplesPerMeter);
            max_rows = round(params_saved.Tsim / params_saved.dt);
            raw_matrix = NaN(max_rows, num_range_bins);
            current_row = 0;
            last_Lpri = getfield_or(params_saved,'pulse_repetition_interval',1e-3) * params_saved.fs;

        case 'add'
            row = varargin{1}(:)';
            if numel(row) ~= num_range_bins
                % auto-reshape if dimensions changed
                new_n = numel(row);
                tmp = NaN(max_rows, new_n);
                ncopy = min(num_range_bins, new_n);
                if current_row > 0
                    tmp(1:current_row, 1:ncopy) = raw_matrix(1:current_row, 1:ncopy);
                end
                raw_matrix = tmp;
                num_range_bins = new_n;
            end
            if current_row < max_rows
                current_row = current_row + 1;
            else
                raw_matrix(1:end-1,:) = raw_matrix(2:end,:);
            end
            raw_matrix(current_row,:) = row(1:num_range_bins);

        case 'get_filtered'
            if current_row == 0, varargout{1} = []; return; end
            mat = raw_matrix(1:current_row,:);
            varargout{1} = apply_filters(mat, params_saved);

        case 'get_all'
            if current_row == 0
                varargout{1} = []; varargout{2} = []; return;
            end
            raw = raw_matrix(1:current_row,:);
            filtered = apply_filters(raw, params_saved);
            varargout{1} = filtered;
            varargout{2} = raw;

        case 'save_mat'
            if current_row == 0, return; end
            raw = raw_matrix(1:current_row,:);
            filtered = apply_filters(raw, params_saved); %#ok<NASGU>
            fname = getfield_or(params_saved,'autosave_mat_file','rx_matrix_data.mat');
            try
                save(fname,'raw','filtered','params_saved','-v7.3');
                fprintf('[matrix_handler] auto-saved -> %s\n', fname);
            catch ME
                warning('matrix_handler save_mat failed: %s', ME.message);
            end

        case 'reset'
            raw_matrix = []; current_row = 0; num_range_bins = 0;

        otherwise
            error('Unknown matrix_handler command: %s', command);
    end
end

% =========================================================
function filtered = apply_filters(mat, params)
    if size(mat,1) < 2, filtered = mat; return; end
    order = getfield_or(params,'mti_order',1);

    % Higher-order MTI (delay-line canceller)
    mti = mat;
    for o = 1:order
        mti = [mti(1,:); diff(mti)];
    end

    mov_avg = movmean(mti, 3, 1);
    med     = movmedian(mov_avg, 3, 1);

    fs = 1/params.dt;
    try
        [b,a] = butter(min(3,order+1), 0.1/(fs/2), 'high');
        filtered = filter(b, a, med, [], 1);
    catch
        filtered = med;
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
