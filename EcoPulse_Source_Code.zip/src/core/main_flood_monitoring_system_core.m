function results = main_flood_monitoring_system_core(params)
% MAIN_FLOOD_MONITORING_SYSTEM_CORE  Single-run worker used by the main
% script and Monte-Carlo driver.  Takes a params struct, returns results.

    if nargin<1, params = get_params(); end

    % Safety: persistence window must fit within sim time
    if params.Tsim < params.persistenceWindow+5
        params.Tsim = params.persistenceWindow + 60;
    end

    % -------- Initialise modules --------------------------
    matrix_handler('init', params);

    history = struct();
    history.validationActive  = false;
    history.validationStart   = 0;
    history.consecutiveCount  = 0;
    history.pendingStatus     = 'monitoring';
    history.confirmedStatus   = 'monitoring';
    history.lastConfirmedTime = 0;
    history.levelBuffer       = [];

    prevLevel     = [];
    kalmanState   = [];
    timeVec       = 0:params.dt:params.Tsim;
    N             = length(timeVec);

    % -------- Preallocate storage -------------------------
    waterHistory      = zeros(1,N);
    waterKalman       = zeros(1,N);
    stateHistory      = zeros(1,N);
    snrHistory        = zeros(1,N);
    rangeHistory      = zeros(1,N);
    rateHistory       = zeros(1,N);
    forecastHistory   = zeros(1,N);
    riskHistory       = zeros(1,N);
    timeRemHistory    = zeros(1,N);
    lastRangeProfile  = [];
    lastRdMap         = [];
    cfarMaskHist      = [];
    waveDirs          = [];

    % -------- Main simulation loop -------------------------
    for k = 1:N
        t = timeVec(k);

        % Weather update
        w = weather_model(t, params);
        params.wind_speed_U10 = w.U10;
        params.rain_rate_mmph = w.rain;

        % Mode switching
        if strcmp(history.confirmedStatus,'monitoring'), mode = 1; else, mode = 2; end

        % 1) Signal Generation
        [tx_signal,~,~] = signal_generation(mode, params);

        % 2) Environment Model
        [rx_signal, meta] = environment_model(tx_signal, params, t);

        % 3) Signal Processing
        proc = signal_processing(tx_signal, rx_signal, params, meta);

        % 4) Feature Extraction (with Kalman)
        features = feature_extraction(proc, prevLevel, params, meta, kalmanState);
        kalmanState = features.kalmanState;
        features.timestamp = t;

        % 5) Decision Logic
        decision = decision_logic(features, params, history);

        % 6) Alarm Validation
        vd = alarm_validation(decision, history, params);
        history = vd.history;

        % -------- Store ---------------------------------------
        waterHistory(k)    = features.waterLevel;
        waterKalman(k)     = features.waterLevel;
        snrHistory(k)      = features.snr;
        rangeHistory(k)    = features.range;
        rateHistory(k)     = features.rateOfRise;
        forecastHistory(k) = decision.forecastLevel;
        riskHistory(k)     = decision.riskProb;
        timeRemHistory(k)  = vd.timeRemaining;

        switch vd.confirmedStatus
            case 'monitoring', stateHistory(k)=0;
            case 'alert',      stateHistory(k)=1;
            otherwise,         stateHistory(k)=2;
        end

        prevLevel = features.waterLevel;
        lastRangeProfile = proc.range_profile;
        if isfield(proc,'rd_map') && ~isempty(proc.rd_map), lastRdMap = proc.rd_map; end
        if isfield(proc,'cfar_mask')
            cfarMaskHist = [cfarMaskHist; double(proc.cfar_mask)]; %#ok<AGROW>
        end
        waveDirs = [waveDirs; 2*pi*rand]; %#ok<AGROW> % placeholder
    end

    % -------- Get matrix data -----------------------------
    [filteredMatrix, rawMatrix] = matrix_handler('get_all');

    % -------- Pack Results --------------------------------
    results = struct();
    results.time              = timeVec;
    results.waterLevel        = waterHistory;
    results.waterLevelKalman  = waterKalman;
    results.rateOfRise        = rateHistory;
    results.state             = stateHistory;
    results.snr               = snrHistory;
    results.range             = rangeHistory;
    results.rangeProfile      = lastRangeProfile;
    results.rdMap             = lastRdMap;
    results.cfarMaskHist      = cfarMaskHist;
    results.matrixData        = filteredMatrix;
    results.rawMatrix         = rawMatrix;
    results.forecastLevel     = forecastHistory;
    results.riskProb          = riskHistory;
    results.timeRemaining     = timeRemHistory;
    results.waveDirs          = waveDirs;
    results.finalStatus       = history.confirmedStatus;
    if strcmp(history.confirmedStatus,'monitoring'), results.finalMode = 1;
    else, results.finalMode = 2; end
end
