function rx_out = ray_tracing(rx_in, tx_signal, currentRange, params)
% RAY_TRACING  Simplified image-method ray tracing for wadi multipath.
%
% Adds two additional copies of the transmitted signal corresponding to
% reflections off the two wadi walls.  This is a first-order approximation
% to full ray-tracing and is activated by params.raytracing == true.

    rx_out = rx_in;
    if ~getfield_or(params,'raytracing',false), return; end

    N = length(rx_in);
    wallOffset = [6 10];           % metres to each wall (idealised)
    reflCoef   = [0.07 0.05];      % wall reflectivity
    for i = 1:numel(wallOffset)
        R = currentRange + wallOffset(i);
        d = round(R * params.samplesPerMeter);
        if d < N
            att = 1/(R^2+1);
            rx_out(d+1:end) = rx_out(d+1:end) + att*reflCoef(i)*tx_signal(1:N-d);
        end
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
