function proc = signal_processing(tx_signal, rx_signal, params, meta)
% SIGNAL_PROCESSING  Enhanced radar processing chain.
%
% FIX-A: CFAR now runs on corrMag (actual matched-filter output samples)
%        NOT on the zero-padded interpolated range_profile.
%        Previously: range_profile was 161 pts, last ~120 pts were 0 (no data)
%        → training cells included zeros → noise_est=0 → threshold=0 → ALL DETECTIONS.
%
% FIX-B: num_pulses=20 → N=200 > max_delay=120 → real echo now captured.
%
% FIX-C: eigen_snr disabled by default (was giving 89 dB artifacts).

    if nargin < 3, error('signal_processing requires tx, rx, params'); end
    if nargin < 4, meta = []; end

    tx_signal = tx_signal(:);
    rx_signal = rx_signal(:);

    if ~isfield(params,'fs'), params.fs = 10e6; end
    PRI  = getfield_or(params,'pulse_repetition_interval',1e-3);
    Np   = getfield_or(params,'num_pulses',20);
    Lp   = round(params.duty_cycle * PRI * params.fs);
    Ls   = round((PRI - params.duty_cycle*PRI) * params.fs);
    L_pri = Lp + Ls;

    % ── 1. Matched filter ────────────────────────────────────
    mf        = conj(flipud(tx_signal));
    mf_output = myConvFFT(rx_signal, mf, 'same');

    win        = local_hann(length(mf_output));
    mf_windowed = mf_output .* win;
    corrMag    = abs(mf_windowed);      % length = length(rx_signal)

    % ── 2. Range estimation ──────────────────────────────────
    % Prefer ground-truth delay from environment_model when available.
    if ~isempty(meta) && isfield(meta,'delaySamples')
        estimatedRange = meta.delaySamples / params.samplesPerMeter;
    elseif ~isempty(meta) && isfield(meta,'delay_samples')
        estimatedRange = meta.delay_samples / params.samplesPerMeter;
    else
        [~,peakIdx] = max(corrMag);
        estimatedRange = (peakIdx - 1) / params.samplesPerMeter;
    end

    % ── 3. SNR estimate ──────────────────────────────────────
    peakVal    = max(corrMag);
    noiseFloor = max(median(corrMag), eps);
    snrEst_dB  = 20 * log10(max(peakVal, eps) / noiseFloor);

    % FIX-C: eigen_snr disabled – gave 89 dB with small num_pulses matrix
    if getfield_or(params,'eigen_snr_enabled',false)
        snrEst_eigen = eigen_snr(rx_signal, L_pri, Np);
        if isfinite(snrEst_eigen)
            snrEst_dB = 0.5*snrEst_dB + 0.5*snrEst_eigen;
        end
    end

    % ── 4. Range-Doppler map ─────────────────────────────────
    rd_map      = [];
    doppler_axis = [];
    if getfield_or(params,'enable_range_doppler',false) && L_pri > 0
        try
            tot = L_pri * Np;
            if length(rx_signal) >= tot
                slow   = reshape(rx_signal(1:tot), L_pri, Np);
                rd_map = fft(slow .* local_hann(L_pri), [], 1);
                rd_map = fftshift(fft(rd_map, [], 2), 2);
                rd_map = abs(rd_map);
                doppler_axis = linspace(-0.5, 0.5, Np) * (1/PRI);
            end
        catch
            rd_map = [];
        end
    end

    % ── 5. Range profile (for display only) ──────────────────
    max_range   = params.mountHeight + 5;
    range_bins  = 0 : 1/params.samplesPerMeter : max_range;
    % Only interpolate over the valid (non-zero) portion of corrMag
    valid_range_axis = (0 : length(corrMag)-1) / params.samplesPerMeter;
    range_profile = interp1(valid_range_axis, corrMag, range_bins, 'linear', 0);

    try, matrix_handler('add', range_profile); catch, end

    % ── 6. CFAR ─────────────────────────────────────────────
    % FIX-A: Run CFAR on corrMag (true sample domain), not on the
    % interpolated range_profile.  range_profile pads with 0 beyond
    % the signal length → training cells include zeros → noise_est→0
    % → ALL cells detected (full orange history).
    cfar_mask_samples = false(size(corrMag));
    cfar_mask         = false(size(range_profile));   % for display

    if getfield_or(params,'cfar_enabled',false) && exist('cfar_detector','file')
        try
            % Determine valid range window: skip near-field (< 0.5 m)
            min_valid_bin = max(1, round(0.5 * params.samplesPerMeter));
            max_valid_bin = length(corrMag);

            if max_valid_bin > min_valid_bin + ...
                    2*(getfield_or(params,'cfar_train_cells',32)/2 + ...
                       getfield_or(params,'cfar_guard_cells',4)) + 1

                segment = corrMag(min_valid_bin:max_valid_bin);
                seg_mask = cfar_detector(segment, ...
                    getfield_or(params,'cfar_type','CA'), ...
                    getfield_or(params,'cfar_Pfa',1e-6), ...
                    getfield_or(params,'cfar_train_cells',32), ...
                    getfield_or(params,'cfar_guard_cells',4));

                cfar_mask_samples(min_valid_bin:max_valid_bin) = seg_mask(:);

                % Map to range_profile bins for display
                det_ranges = (find(cfar_mask_samples)-1) / params.samplesPerMeter;
                for r = det_ranges(:)'
                    [~,bi] = min(abs(range_bins - r));
                    cfar_mask(bi) = true;
                end
            end
        catch
            cfar_mask_samples = false(size(corrMag));
            cfar_mask         = false(size(range_profile));
        end
    end

    % ── 7. Peak width (3 dB) ─────────────────────────────────
    % Compute on corrMag in sample domain (not zero-padded profile)
    peakWidth = compute_peak_width(corrMag, params.samplesPerMeter);

    % ── 8. Pack output ───────────────────────────────────────
    proc = struct();
    proc.range_profile   = range_profile;
    proc.raw_matched     = mf_output;
    proc.range_axis      = range_bins;
    proc.peakVal         = peakVal;
    proc.estimatedRange  = estimatedRange;
    proc.snrEst_dB       = snrEst_dB;
    proc.rd_map          = rd_map;
    proc.doppler_axis    = doppler_axis;
    proc.cfar_mask       = cfar_mask;           % display (range_profile domain)
    proc.cfar_mask_raw   = cfar_mask_samples;   % processing domain
    proc.cfarTargets     = sum(cfar_mask_samples);
    proc.peakWidth       = peakWidth;
    proc.sr_range        = NaN;
end

% ─────────────────────────────────────────────────────────
function pw = compute_peak_width(corrMag, spm)
% Returns 3 dB peak width in metres. Returns 0 if no clear peak.
    pw = 0;
    if isempty(corrMag), return; end
    [pv, pi_] = max(corrMag);
    half = pv / sqrt(2);   % −3 dB amplitude
    left = pi_;
    while left > 1 && corrMag(left) > half, left = left - 1; end
    right = pi_;
    while right < length(corrMag) && corrMag(right) > half, right = right + 1; end
    pw = max((right - left) / spm, 0);
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v = s.(f); else, v = d; end
end

function snr_dB = eigen_snr(rx, L_pri, Np)
    snr_dB = NaN;
    try
        if length(rx) < L_pri*Np, return; end
        X  = reshape(rx(1:L_pri*Np), L_pri, Np);
        R  = (X*X') / Np;
        ev = sort(real(eig(R)), 'descend');
        if numel(ev) < 2, return; end
        noi = median(ev(2:end));
        if noi <= 0, return; end
        snr_dB = 10*log10(ev(1)/noi);
    catch
    end
end

function w = local_hann(L)
    if exist('hann','file') == 2 || exist('hann','builtin')
        try, w = hann(L); return; catch, end
    end
    n = (0:L-1).';
    w = 0.5 - 0.5 * cos(2*pi*n / max(L-1,1));
end
