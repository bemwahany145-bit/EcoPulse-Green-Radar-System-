function rng_est = music_esprit(rx_signal, params, method, K)
% MUSIC_ESPRIT  Super-resolution range estimation for one or few targets.
%
%   rng_est = music_esprit(rx, params, 'music', 1)
%   rng_est = music_esprit(rx, params, 'esprit', 1)
%
% Uses subspace methods on a Hankel-like sample covariance of the
% range-compressed signal.  Returns the estimated range(s) in metres.

    if nargin<4, K=1; end
    x = rx_signal(:);
    M = 32;                     % sub-array length
    N = length(x) - M + 1;
    if N < M, rng_est = NaN; return; end

    X = zeros(M,N);
    for i = 1:N, X(:,i) = x(i:i+M-1); end
    R = (X*X')/N;

    % eigen-decomp
    [U,D] = eig(R);
    [d,idx] = sort(real(diag(D)),'descend');
    U = U(:,idx);
    Un = U(:,K+1:end);          % noise subspace

    % search over possible delays (0..mountHeight+5)
    fs = params.fs;
    max_range = params.mountHeight + 5;
    delays = linspace(1, round(max_range*params.samplesPerMeter), 256);
    P = zeros(size(delays));
    m = (0:M-1).';
    for i = 1:length(delays)
        a = exp(-1j*2*pi*delays(i)*m/length(x));
        switch lower(method)
            case 'music'
                P(i) = 1 ./ (abs(a'*Un*Un'*a)+eps);
            case 'esprit'
                P(i) = abs(a'*R*a);
            otherwise
                P(i) = 1 ./ (abs(a'*Un*Un'*a)+eps);
        end
    end
    [~,ix] = max(P);
    delay_samples_est = delays(ix);
    rng_est = delay_samples_est / params.samplesPerMeter;
end
