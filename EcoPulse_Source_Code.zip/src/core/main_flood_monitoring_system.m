% MAIN_FLOOD_MONITORING_SYSTEM  Enhanced flood monitoring radar pipeline.
%
% Runs: signal gen -> environment -> signal processing -> feature extraction
%       -> decision logic -> alarm validation -> visualisation.
%
% All behaviour is driven by get_params().  To run Monte-Carlo mode set
% params.mc_runs > 0.

clc; clear; close all;

disp('=================================================');
disp('Radar - Enhanced Flood Monitoring System');
disp('=================================================');

% -------- Load parameters (optionally from JSON) --------
if exist('config_default.json','file')
    params = get_params('config_default.json');
else
    params = get_params('slow_rise');
end

% Monte-Carlo branch
if isfield(params,'mc_runs') && params.mc_runs > 0
    mc = run_monte_carlo(params, params.mc_runs);
    fprintf('\nMonte-Carlo Pd=%.3f  Pfa=%.3f\n', mc.Pd, mc.Pfa);
    results = main_flood_monitoring_system_core(params);
    results.roc = mc.roc;
else
    results = main_flood_monitoring_system_core(params);
end

% -------- Visualisation ---------------------------------
use_gui_flag        = isfield(params,'use_gui')           && params.use_gui;
autosave_flag       = ~isfield(params,'autosave_enabled') || params.autosave_enabled;
export_flag         = isfield(params,'export_report')     && params.export_report;

if use_gui_flag
    flood_gui(results, params);
else
    dashboard_philip(results, params);
end
animate_flood_3d(results, params);

if autosave_flag
    try, matrix_handler('save_mat'); catch, end
end
if export_flag
    try, export_report(results, params); catch ME
        warning('export_report: %s', ME.message);
    end
end

disp('System Finished.');
