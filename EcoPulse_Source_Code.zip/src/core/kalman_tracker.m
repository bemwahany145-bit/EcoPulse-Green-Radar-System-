function [xEst, state] = kalman_tracker(z, dt, state)
% KALMAN_TRACKER  Constant-velocity Kalman filter for water level tracking.
%
% Usage inside a time loop:
%   state = [];              % before loop
%   for each measurement z:
%       [xEst, state] = kalman_tracker(z, dt, state);
%       level_hat = xEst(1);
%       rate_hat  = xEst(2);
%
% State:  x = [level; rate]
% Model:  x_{k+1} = F x_k + w,   z_k = H x_k + v

    if isempty(state)
        state.x = [z; 0];
        state.P = diag([1 0.01]);
        state.Q = diag([1e-4 1e-6]);   % process noise
        state.R = 0.01;                % measurement noise variance
    end

    F = [1 dt; 0 1];
    H = [1 0];

    % predict
    x = F * state.x;
    P = F * state.P * F' + state.Q;

    % update
    y = z - H*x;
    S = H*P*H' + state.R;
    K = P*H'/S;
    x = x + K*y;
    P = (eye(2) - K*H) * P;

    state.x = x;
    state.P = P;
    xEst = x;
end
