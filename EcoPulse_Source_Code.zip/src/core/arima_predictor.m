function [pred, pStd] = arima_predictor(history, features, params)
% ARIMA_PREDICTOR  Lightweight water-level forecaster.
%
%   history  : struct with field levelBuffer (vector of past levels)
%   features : current features struct
%   params   : shared parameter struct
%
% Strategy:
%   * If Econometrics Toolbox is available -> fit ARIMA(1,1,1)
%   * Otherwise fall back to linear regression on the recent buffer
%
% RETURNS:
%   pred : predicted water level at params.forecast_horizon_s
%   pStd : estimated std-dev of prediction (for risk probability)

    horizon = params.forecast_horizon_s;
    histLen = params.forecast_history_s;

    if ~isfield(history,'levelBuffer') || isempty(history.levelBuffer)
        pred = features.waterLevel + features.rateOfRise*horizon;
        pStd = 0.2;
        return;
    end

    buf = history.levelBuffer(:);
    if length(buf) < 4
        pred = features.waterLevel + features.rateOfRise*horizon;
        pStd = 0.2;
        return;
    end

    % ---- try ARIMA from Econometrics Toolbox -------------------------
    used_arima = false;
    try
        if exist('arima','class')==8 || exist('arima','file')==2
            mdl = arima('ARLags',1,'D',1,'MALags',1);
            estMdl = estimate(mdl, buf, 'Display','off');
            [Y,YMSE] = forecast(estMdl, horizon, 'Y0', buf);
            pred = Y(end);
            pStd = sqrt(YMSE(end));
            used_arima = true;
        end
    catch
    end

    if ~used_arima
        % linear regression fall-back
        n = length(buf);
        t = (0:n-1)' * params.dt;
        A = [t ones(n,1)];
        theta = A \ buf;                 % slope, intercept
        t_future = t(end) + horizon;
        pred = theta(1)*t_future + theta(2);
        resid = buf - A*theta;
        pStd = std(resid) + 1e-3;
    end
end
