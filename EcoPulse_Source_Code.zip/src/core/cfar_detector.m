function mask = cfar_detector(profile, type, Pfa, Ntrain, Nguard)
% CFAR_DETECTOR  Constant False Alarm Rate detector.
%
% FIX: Added guard against near-zero noise_est to prevent false alarms
%      when training cells contain zero-padded extrapolated values.
%      Also added OS-CFAR correction for Pfa.

    if nargin < 2, type   = 'CA';  end
    if nargin < 3, Pfa    = 1e-6;  end   % FIX: tighter default
    if nargin < 4, Ntrain = 32;    end   % FIX: more training cells
    if nargin < 5, Nguard = 4;     end

    x    = abs(profile(:)).^2;
    N    = length(x);
    mask = false(N,1);

    half = round(Ntrain/2) + Nguard;
    if N < 2*half + 1, return; end

    % Minimum noise floor: 1% of mean signal power
    % Prevents threshold collapsing to zero near zero-padded regions
    min_noise = 0.01 * mean(x(x > 0) + eps);
    if isnan(min_noise) || min_noise <= 0, min_noise = eps; end

    switch upper(type)
        case 'CA'
            alpha = Ntrain * (Pfa^(-1/Ntrain) - 1);
            for idx = (half+1) : (N-half)
                lead = x(idx - half      : idx - Nguard - 1);
                lag  = x(idx + Nguard + 1 : idx + half);
                noise_est = max(mean([lead; lag]), min_noise);  % FIX: floor
                T = alpha * noise_est;
                if x(idx) > T
                    mask(idx) = true;
                end
            end

        case 'OS'
            k     = round(0.75 * Ntrain);
            alpha = k * (Pfa^(-1/k) - 1);
            for idx = (half+1) : (N-half)
                cells = [x(idx-half : idx-Nguard-1);
                         x(idx+Nguard+1 : idx+half)];
                cells     = sort(cells, 'ascend');
                noise_est = max(cells(min(k,end)), min_noise);  % FIX: floor
                T = alpha * noise_est;
                if x(idx) > T
                    mask(idx) = true;
                end
            end

        otherwise
            error('Unknown CFAR type: %s', type);
    end

    mask = mask(:)';
end
