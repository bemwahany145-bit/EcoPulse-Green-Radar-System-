function validatedDecision = alarm_validation(decision, history, params)
% ALARM_VALIDATION  Enhanced persistence + forecast-aware alarm confirmer.
%
% Same API as the original; additional fields now expose the countdown
% timer and forecast-based early warning.

    % --- fill missing history fields -------------------------
    hd = struct('validationActive',false,'validationStart',0, ...
                'consecutiveCount',0,'pendingStatus','monitoring', ...
                'confirmedStatus','monitoring','lastConfirmedTime',0, ...
                'levelBuffer',[]);
    f = fieldnames(hd);
    for i=1:numel(f)
        if ~isfield(history,f{i}), history.(f{i})=hd.(f{i}); end
    end

    % store into sliding buffer (used by arima)
    history.levelBuffer = [history.levelBuffer; decision.waterLevel];
    maxHist = max(10, round(getfield_or(params,'forecast_history_s',30)/params.dt));
    if length(history.levelBuffer) > maxHist
        history.levelBuffer = history.levelBuffer(end-maxHist+1:end);
    end

    % --- output scaffold -------------------------------------
    initMode = getMode(history.confirmedStatus);
    validatedDecision.confirmedStatus   = history.confirmedStatus;
    validatedDecision.confirmedMode     = initMode;
    validatedDecision.alarmConfirmed    = false;
    validatedDecision.validating        = history.validationActive;
    validatedDecision.timeInValidation  = 0;
    validatedDecision.timeRemaining     = params.persistenceWindow;
    validatedDecision.waterLevel        = decision.waterLevel;
    validatedDecision.rateOfRise        = decision.rateOfRise;
    validatedDecision.snr               = decision.snr;
    validatedDecision.timestamp         = decision.timestamp;
    validatedDecision.forecastLevel     = getfield_or(decision,'forecastLevel',NaN);
    validatedDecision.riskProb          = getfield_or(decision,'riskProb',0);

    % --- main persistence logic ------------------------------
    if decision.changeDetected && decision.snrValid
        if ~history.validationActive
            history.validationActive  = true;
            history.validationStart   = decision.timestamp;
            history.consecutiveCount  = 1;
            history.pendingStatus     = decision.status;
            fprintf('[alarm_validation] t=%5.1fs | Change detected (%s) -> Timer STARTED\n', ...
                decision.timestamp, decision.status);
        else
            history.consecutiveCount = history.consecutiveCount + 1;
            history.pendingStatus    = getMoreSevere(history.pendingStatus, decision.status);
        end

        elapsed = decision.timestamp - history.validationStart;
        remaining = max(0, params.persistenceWindow - elapsed);
        validatedDecision.timeInValidation = elapsed;
        validatedDecision.timeRemaining    = remaining;
        validatedDecision.validating       = true;

        if elapsed >= params.persistenceWindow && ...
           history.consecutiveCount >= params.persistenceCount
            history.confirmedStatus   = history.pendingStatus;
            history.lastConfirmedTime = decision.timestamp;
            history.validationActive  = false;
            history.validationStart   = 0;
            history.consecutiveCount  = 0;
            history.pendingStatus     = 'monitoring';

            validatedDecision.confirmedStatus  = history.confirmedStatus;
            validatedDecision.confirmedMode    = getMode(history.confirmedStatus);
            validatedDecision.alarmConfirmed   = true;
            validatedDecision.validating       = false;
            validatedDecision.timeInValidation = elapsed;
            validatedDecision.timeRemaining    = 0;
            fprintf('[alarm_validation] t=%5.1fs | *** ALARM CONFIRMED: %s *** | %.1fs elapsed\n', ...
                decision.timestamp, history.confirmedStatus, elapsed);
        else
            fprintf('[alarm_validation] t=%5.1fs | Validating %s | %.1f/%ds | count=%d | remain=%.0fs\n',...
                decision.timestamp, history.pendingStatus, elapsed, ...
                params.persistenceWindow, history.consecutiveCount, remaining);
        end
    else
        if history.validationActive
            elapsed = decision.timestamp - history.validationStart;
            fprintf('[alarm_validation] t=%5.1fs | Change gone after %.1fs -> Timer RESET\n', ...
                decision.timestamp, elapsed);
            history.validationActive = false;
            history.validationStart  = 0;
            history.consecutiveCount = 0;
            history.pendingStatus    = 'monitoring';
        end
        validatedDecision.confirmedStatus  = history.confirmedStatus;
        validatedDecision.confirmedMode    = getMode(history.confirmedStatus);
        validatedDecision.validating       = false;
        validatedDecision.timeInValidation = 0;
        validatedDecision.timeRemaining    = params.persistenceWindow;
    end

    validatedDecision.history = history;

    fprintf('[alarm_validation] t=%5.1fs | Confirmed: %s | Mode=%d | AlarmFired=%d | Risk=%.2f\n', ...
        decision.timestamp, validatedDecision.confirmedStatus, ...
        validatedDecision.confirmedMode, validatedDecision.alarmConfirmed, ...
        validatedDecision.riskProb);
end

% =========================================================
function m = getMode(status)
    if strcmp(status,'monitoring'), m=1; else, m=2; end
end
function s = getMoreSevere(a,b)
    levels = {'monitoring','alert','flood_risk'};
    ia = find(strcmp(levels,a),1); if isempty(ia), ia=1; end
    ib = find(strcmp(levels,b),1); if isempty(ib), ib=1; end
    if ib>ia, s=b; else, s=a; end
end
function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
