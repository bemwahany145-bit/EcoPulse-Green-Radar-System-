function w = weather_model(t, params)
% WEATHER_MODEL  Returns weather parameters (wind U10, rain rate) at time t.
%
% If params.weather_file is provided and exists, it is expected to be a
% CSV with columns [time_s, U10, rain_mmph].  Otherwise a synthetic
% diurnal-like profile is produced for demos.

    w = struct('U10', getfield_or(params,'wind_speed_U10',6), ...
               'rain', getfield_or(params,'rain_rate_mmph',0));

    fn = getfield_or(params,'weather_file','');
    if ~isempty(fn) && exist(fn,'file')
        persistent W tbl
        if isempty(W)
            try
                tbl = readmatrix(fn);
                W = tbl;
            catch
                W = []; tbl = [];
            end
        end
        if ~isempty(tbl)
            w.U10  = interp1(tbl(:,1), tbl(:,2), t, 'linear','extrap');
            w.rain = interp1(tbl(:,1), tbl(:,3), t, 'linear','extrap');
            return;
        end
    end

    % synthetic profile - gusty wind and possible rain event
    w.U10  = max(1, 6 + 2*sin(2*pi*t/80));
    if t > 30 && t < 90
        w.rain = 5*max(0, sin(pi*(t-30)/60));  % peak rain in middle
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
