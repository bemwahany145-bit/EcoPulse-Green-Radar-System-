function decision = decision_logic(features, params, history)
% DECISION_LOGIC  Enhanced threshold / ML / forecast-based decision.
%
% FIX: riskProb was either 0 or 0.8 (jump). Now computed as a smooth
%      continuous probability that ramps from 0 -> 1 as forecast approaches
%      the flood threshold. This prevents the gauge from showing 100%
%      immediately from t=5s.

    if nargin < 3, history = struct(); end

    decision.mode           = 1;
    decision.status         = 'monitoring';
    decision.levelFlag      = false;
    decision.rateFlag       = false;
    decision.snrValid       = false;
    decision.changeDetected = false;
    decision.timestamp      = features.timestamp;
    decision.waterLevel     = features.waterLevel;
    decision.rateOfRise     = features.rateOfRise;
    decision.snr            = features.snr;
    decision.forecastLevel  = NaN;
    decision.riskProb       = 0;
    decision.mlLabel        = "";

    % --- SNR gate --------------------------------------------
    if features.snr >= params.snrThreshold
        decision.snrValid = true;
    else
        fprintf('[decision_logic] t=%5.1fs | SNR=%.1fdB < %.1f -> ignored\n', ...
            features.timestamp, features.snr, params.snrThreshold);
        return;
    end

    % --- Threshold rules -------------------------------------
    if features.waterLevel >= params.levelFlood
        decision.levelFlag = true; decision.status='flood_risk'; decision.mode=2;
    elseif features.waterLevel >= params.levelAlert
        decision.levelFlag = true; decision.status='alert';      decision.mode=2;
    end
    if features.rateOfRise >= params.rateFlood
        decision.rateFlag = true;
        if ~strcmp(decision.status,'flood_risk')
            decision.status='flood_risk'; decision.mode=2;
        end
    elseif features.rateOfRise >= params.rateAlert
        decision.rateFlag = true;
        if strcmp(decision.status,'monitoring')
            decision.status='alert'; decision.mode=2;
        end
    end
    if decision.levelFlag || decision.rateFlag
        decision.changeDetected = true;
    end

    % --- Forecasting (ARIMA / linear) -----------------------
    if getfield_or(params,'forecast_enabled',false) && exist('arima_predictor','file')
        try
            [pred, pStd] = arima_predictor(history, features, params);
            decision.forecastLevel = pred;
            if pStd > 0
                z = (params.levelFlood - pred) / pStd;
                decision.riskProb = 1 - 0.5*erfc(-z/sqrt(2));
            else
                % FIX: smooth sigmoid instead of hard 0/0.8 jump
                decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
            end
        catch
            horizon = getfield_or(params,'forecast_horizon_s',30);
            pred = features.waterLevel + features.rateOfRise * horizon;
            decision.forecastLevel = pred;
            % FIX: continuous probability ramp - was 0.8 fixed value
            decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
        end
    else
        horizon = getfield_or(params,'forecast_horizon_s',30);
        pred = features.waterLevel + features.rateOfRise * horizon;
        decision.forecastLevel = pred;
        % FIX: continuous probability ramp
        decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
    end

    % --- ML classifier (optional) ---------------------------
    if getfield_or(params,'ml_classifier_enabled',false) && exist('ml_classifier','file')
        try
            decision.mlLabel = ml_classifier(features, params);
            if strcmpi(decision.mlLabel,'flood_risk') && strcmp(decision.status,'monitoring')
                decision.status = 'alert';
                decision.changeDetected = true;
                decision.mode = 2;
            end
        catch
        end
    end

    fprintf('[decision_logic] t=%5.1fs | WL=%.3fm Rate=%.4fm/s SNR=%.1fdB | %s | Fcst=%.2f Risk=%.2f\n',...
        features.timestamp, features.waterLevel, features.rateOfRise, ...
        features.snr, decision.status, decision.forecastLevel, decision.riskProb);
end

% FIX: smooth sigmoid-based risk probability
% Returns 0 when pred << levelAlert, 0.5 at levelFlood, 1.0 well above flood.
function p = smooth_risk(pred, levelAlert, levelFlood)
    span = levelFlood - levelAlert;          % transition width
    centre = levelFlood;                     % 50% probability at flood level
    steepness = 6 / max(span, 0.1);         % sigmoid steepness
    p = 1 / (1 + exp(-steepness * (pred - centre)));
    p = min(max(p, 0), 1);
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
