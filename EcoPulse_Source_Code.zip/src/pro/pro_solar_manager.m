function sol = pro_solar_manager(t, energy_used_J, params)
%PRO_SOLAR_MANAGER  Solar harvest + battery budgeting.
    solar_W = getfield_or(params,'solar_panel_W', 30);
    cap_Wh  = getfield_or(params,'battery_capacity_Wh', 50);
    hour = mod(t/3600, 24);
    if hour >= 6 && hour <= 18
        irr = sin(pi*(hour-6)/12);
    else
        irr = 0;
    end
    sol.solar_W     = irr * solar_W;
    sol.harvested_J = sol.solar_W * params.dt;
    cap_J = cap_Wh * 3600;
    sol.battery_pct = max(0, min(100, 100*(cap_J - energy_used_J + sol.harvested_J)/cap_J));
    sol.sustainability = sol.harvested_J / max(1e-6, energy_used_J/max(t,1)*params.dt);
end
function v = getfield_or(s,f,d), if isfield(s,f), v=s.(f); else, v=d; end; end
