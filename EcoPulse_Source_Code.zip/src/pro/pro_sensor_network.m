function net = pro_sensor_network(features, params, N)
%PRO_SENSOR_NETWORK  Simulated distributed N-node radar network.
    if nargin<3, N = 3; end
    net = struct('N',N);
    net.levels = zeros(1,N);
    net.snr    = zeros(1,N);
    net.status = cell(1,N);
    for i = 1:N
        net.levels(i) = features.waterLevel + 0.05*randn;
        net.snr(i)    = features.snr + 2*randn;
        if net.levels(i) >= params.levelFlood
            net.status{i} = 'FLOOD';
        elseif net.levels(i) >= params.levelAlert
            net.status{i} = 'ALERT';
        else
            net.status{i} = 'OK';
        end
    end
    net.consensus = median(net.levels);
    net.health = 1 - sum(strcmp(net.status,'FLOOD'))/N;
end
