function yhat = pro_lstm_forecaster(history, horizon)
%PRO_LSTM_FORECASTER  Simplified LSTM-style recurrent forecaster.
%   Hand-rolled gates (no Deep Learning Toolbox).
    h = history(:); N = length(h);
    if N < 8, yhat = h(end); return; end
    mu = mean(h); sd = std(h) + 1e-6;
    z = (h - mu) / sd;
    h_t = 0; c_t = 0;
    Wf = 0.4; Wi = 0.5; Wo = 0.3; Wc = 0.6;
    for k = 1:N
        ft = sigmoid(Wf*z(k) + 0.1*h_t);
        it = sigmoid(Wi*z(k) + 0.1*h_t);
        ct = tanh(Wc*z(k) + 0.1*h_t);
        c_t = ft*c_t + it*ct;
        ot = sigmoid(Wo*z(k) + 0.1*h_t);
        h_t = ot*tanh(c_t);
    end
    yhat_z = h_t + 0.02 * horizon;
    yhat = yhat_z * sd + mu;
    if ~isfinite(yhat), yhat = h(end); end
end
function y = sigmoid(x), y = 1./(1+exp(-x)); end
