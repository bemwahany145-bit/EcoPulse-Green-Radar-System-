function def = pro_cyber_defense(rx, params)
%PRO_CYBER_DEFENSE  Jamming and spoofing detection.
    def = struct('jamming',false,'spoofing',false,'score',0);
    if nargin<1 || isempty(rx), return; end
    nf = median(abs(rx));
    noise_floor = sqrt(getfield_or(params,'clutterLevel',0.08));
    if nf > 10*noise_floor, def.jamming = true; end
    if numel(rx) > 32
        a = abs(rx); da = diff(a);
        if max(abs(da)) > 20*std(da), def.spoofing = true; end
    end
    def.score = double(def.jamming)*0.6 + double(def.spoofing)*0.4;
end
function v = getfield_or(s,f,d), if isfield(s,f), v=s.(f); else, v=d; end; end
