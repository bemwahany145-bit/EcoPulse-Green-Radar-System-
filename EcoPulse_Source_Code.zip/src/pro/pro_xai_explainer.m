function exp = pro_xai_explainer(features, decision)
%PRO_XAI_EXPLAINER  SHAP-like feature-importance explanation.
%
% FIX: Baseline values were [1.0, 0.005, 1.0, 15, 0.5, 3].
%      peakWidth base=0.5 and cfarTargets base=3 are unrealistic early-sim:
%      - peakWidth typically 0.1-0.3m (not 0.5)
%      - cfarTargets typically 0-1 (not 3) with proper signal length
%      These caused permanent negative bars in the XAI chart.
%
%      ALSO: features now contains 'surfaceVz' not 'peakWidth' as 6th item
%      in some calls. We guard against missing fields.

    names = {'SNR','level','vz','cfar','peakW','rate'};

    % Safe field reads
    snr_val   = getf(features, 'snr',         15);
    level_val = getf(features, 'waterLevel',   0.5);
    vz_val    = abs(getf(features, 'surfaceVz', 0));
    cfar_val  = getf(features, 'cfarTargets',  0);
    peak_val  = getf(features, 'peakWidth',    0);
    rate_val  = getf(features, 'rateOfRise',   0);
    fcst_val  = getf(decision,  'forecastLevel', level_val);

    vals = [snr_val, level_val, vz_val, cfar_val, peak_val, rate_val];

    % FIX: baselines reflect realistic early-simulation values
    % (before any flood event) so contributions start near zero
    % and grow as the situation worsens.
    base = [15,   ...  % SNR: typical good-signal value (dB)
            0.5,  ...  % waterLevel: initial level (m)
            0.05, ...  % surfaceVz: calm water baseline (m/s)
            1,    ...  % cfarTargets: 1 target expected when echo present
            0.12, ...  % peakWidth: typical matched-filter 3dB width (m)
            0.0];      % rateOfRise: zero at start

    % Normalise by max(|base|, small_floor) to avoid divide-by-zero
    norm_base = max(abs(base), [1, 0.5, 0.01, 1, 0.05, 0.005]);

    % Weights: how much each feature should influence the risk score
    w = [0.15, 0.35, 0.05, 0.10, 0.10, 0.25];

    delta   = vals - base;
    contrib = w .* (delta ./ norm_base);

    % Clamp to [-1, 1] per feature
    contrib = max(min(contrib, 1), -1);

    [~, idx] = sort(abs(contrib), 'descend');

    exp.names        = names;
    exp.values       = vals;
    exp.contrib      = contrib;
    exp.ranked       = idx;
    exp.top1         = names{idx(1)};
    exp.top1_contrib = contrib(idx(1));
    exp.forecastLevel = fcst_val;
end

function v = getf(s, f, def)
    if isstruct(s) && isfield(s, f), v = s.(f); else, v = def; end
end
