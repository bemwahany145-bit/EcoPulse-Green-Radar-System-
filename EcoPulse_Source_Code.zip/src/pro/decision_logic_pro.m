function decision = decision_logic_pro(features, params, history, pro_state)
%DECISION_LOGIC_PRO  Enhanced decision logic with Fuzzy, Bayes and XAI.
%   Drop-in replacement for decision_logic.m that additionally calls the
%   pro_fuzzy_risk, pro_bayes_detector and pro_xai_explainer modules.
%
%   Usage (from main loop):
%       persistent pro_state
%       if isempty(pro_state), pro_state = struct('bayesLLR',0); end
%       decision = decision_logic_pro(features, params, history, pro_state);
%       pro_state = decision.pro_state;    % persist across ticks

    if nargin < 3, history = struct(); end
    if nargin < 4, pro_state = struct('bayesLLR', 0); end

    % --- Start from standard decision -----------------------------
    decision = decision_logic(features, params, history);

    % --- Fuzzy risk (soft) ----------------------------------------
    try, riskFuzzy = pro_fuzzy_risk(features, params); catch, riskFuzzy = 0; end
    decision.riskFuzzy = riskFuzzy;

    % --- Bayesian SPRT --------------------------------------------
    try
        [LLR, bflag] = pro_bayes_detector(features, pro_state.bayesLLR, params);
        pro_state.bayesLLR = LLR;
        decision.bayesLLR  = LLR;
        decision.bayesFlag = bflag;
    catch
        decision.bayesFlag = false;
    end

    % --- Combined risk (weighted fusion of all evidence) ----------
    w_rule   = 0.35 * double(decision.changeDetected);
    w_fuzzy  = 0.25 * riskFuzzy;
    w_bayes  = 0.20 * double(getfield_or(decision,'bayesFlag',false));
    w_arima  = 0.20 * double(decision.riskProb);
    decision.riskProb = min(1, w_rule + w_fuzzy + w_bayes + w_arima);

    % --- XAI explanation ------------------------------------------
    try, decision.xai = pro_xai_explainer(features, decision); catch, end

    decision.pro_state = pro_state;
end

function v = getfield_or(s, f, d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
