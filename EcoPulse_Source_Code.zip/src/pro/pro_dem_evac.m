function out = pro_dem_evac(level, danger_xy)
%PRO_DEM_EVAC  DEM-based shortest evacuation path (Dijkstra-lite).
    if nargin<2, danger_xy = [0 0]; end
    [X,Y] = meshgrid(linspace(-30,30,40), linspace(-15,30,40));
    Z = 0.15*abs(X) + 0.03*Y + 0.5*exp(-(X.^2+Y.^2)/400);
    cost = Z + 3*(Z<level);   % penalize flood-prone
    [R,C] = size(Z);
    [~,sx] = min(abs(X(1,:) - danger_xy(1)));
    [~,sy] = min(abs(Y(:,1) - danger_xy(2)));
    D = inf(R,C); D(sy,sx) = 0; visited = false(R,C);
    queue = [sy sx];
    while ~isempty(queue)
        yx = queue(1,:); queue(1,:) = [];
        y = yx(1); x = yx(2);
        if visited(y,x), continue; end
        visited(y,x) = true;
        for dy = -1:1, for dx = -1:1
            ny = y+dy; nx = x+dx;
            if ny<1||ny>R||nx<1||nx>C, continue; end
            nc = D(y,x) + cost(ny,nx);
            if nc < D(ny,nx)
                D(ny,nx) = nc;
                queue(end+1,:) = [ny nx];
            end
        end, end
    end
    [~,idx] = max(Z(:) - D(:)*0.1);
    [gy,gx] = ind2sub(size(D), idx);
    out.X = X; out.Y = Y; out.Z = Z; out.D = D;
    out.start = [sx sy]; out.goal = [gx gy];
    out.flooded_area = sum(Z(:) < level);
    out.safe_elev = Z(gy,gx);
end
