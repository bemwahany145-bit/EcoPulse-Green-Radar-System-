function twin = pro_digital_twin(level, params, t)
%PRO_DIGITAL_TWIN  Real-time 3D digital twin of the wadi.
%   Computes flooded area, volume and severity index.
    [X,Y] = meshgrid(linspace(-30,30,80), linspace(-15,30,80));
    Z = 0.15*abs(X) + 0.03*Y + 0.5*exp(-(X.^2+Y.^2)/400);
    flooded = Z < level;
    cell_area = (60/80)*(45/80);       % m^2 per cell
    twin = struct();
    twin.X = X; twin.Y = Y; twin.Z = Z;
    twin.level = level;
    twin.time  = t;
    twin.flooded_cells = nnz(flooded);
    twin.flooded_area_m2 = twin.flooded_cells * cell_area;
    twin.flooded_volume_m3 = sum(max(level - Z(flooded), 0)) * cell_area;
    twin.severity = min(1, twin.flooded_area_m2 / (numel(Z)*cell_area) * 3);
    twin.radar_xyz = [0 0 params.mountHeight];
end
