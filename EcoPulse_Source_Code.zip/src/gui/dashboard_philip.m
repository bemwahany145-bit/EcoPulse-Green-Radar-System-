function figHandles = dashboard_philip(results, params)
% DASHBOARD_PHILIP  Enhanced professional dashboard.
%
% Adds to the original 4-panel layout:
%   * Range-Doppler map (panel 5)
%   * Validation countdown timer
%   * Risk probability curve
%   * Statistical indicators (mean, std, peak)
%   * Optional Monte-Carlo ROC curve (if results.roc present)
%   * Tabbed interface (params.use_tabs)
%   * Export-to-PDF button

    if getfield_or(params,'use_tabs',true)
        fig = figure('Name','Flood Monitoring Dashboard (Enhanced)', ...
                     'Position',[80 60 1400 820], 'Color',[0.97 0.98 1]);
        tg = uitabgroup(fig, 'Position',[0 0 1 1]);
        t1 = uitab(tg,'Title','Core Plots');
        t2 = uitab(tg,'Title','Advanced');
        t3 = uitab(tg,'Title','Statistics & Risk');
        parent1 = t1; parent2 = t2; parent3 = t3;
    else
        fig = figure('Name','Flood Monitoring Dashboard (Enhanced)', ...
                     'Position',[80 60 1400 820], 'Color',[0.97 0.98 1]);
        parent1 = fig; parent2 = fig; parent3 = fig;
    end

    % ==========================================================
    % TAB 1 - CORE PLOTS
    % ==========================================================
    ax1 = subplot(2,2,1,'Parent',parent1);
    plot(ax1, results.time, results.waterLevel, 'b-', 'LineWidth', 1.8); hold(ax1,'on');
    yline(ax1, params.levelAlert, '--', 'Alert',  'Color',[1 0.6 0],'LineWidth',1.5);
    yline(ax1, params.levelFlood, '--', 'Flood',  'Color',[0.9 0 0],'LineWidth',1.5);
    if isfield(results,'waterLevelKalman')
        plot(ax1, results.time, results.waterLevelKalman, 'm:','LineWidth',1.2);
        legend(ax1,{'Measured','Alert Th','Flood Th','Kalman'},'Location','best');
    else
        legend(ax1,{'Water Level','Alert Th','Flood Th'},'Location','best');
    end
    grid(ax1,'on'); xlabel(ax1,'Time (s)'); ylabel(ax1,'Water Level (m)');
    title(ax1,'Estimated Water Level');

    ax2 = subplot(2,2,2,'Parent',parent1);
    stairs(ax2, results.time, results.state, 'g-','LineWidth',1.8);
    yticks(ax2,[0 1 2]); yticklabels(ax2,{'Monitoring','Alert','Flood'});
    grid(ax2,'on'); xlabel(ax2,'Time (s)'); ylabel(ax2,'State');
    title(ax2,'System State (Confirmed)');

    ax3 = subplot(2,2,3,'Parent',parent1);
    if isfield(results,'rangeProfile')
        plot(ax3, results.rangeProfile, 'k-', 'LineWidth',1.2); grid(ax3,'on');
        xlabel(ax3,'Range Bin'); ylabel(ax3,'Magnitude'); title(ax3,'Last Range Profile');
    end

    ax4 = subplot(2,2,4,'Parent',parent1);
    if isfield(results,'matrixData') && ~isempty(results.matrixData)
        imagesc(ax4, results.matrixData); colorbar(ax4); colormap(ax4,'jet');
        xlabel(ax4,'Range Bin'); ylabel(ax4,'Dwell Index'); title(ax4,'Filtered Range Matrix');
    end

    % Countdown annotation
    if getfield_or(params,'show_countdown',true) && isfield(results,'timeRemaining')
        remaining = results.timeRemaining(end);
        annotation(parent1,'textbox',[0.87 0.93 0.12 0.05], ...
            'String',sprintf('Countdown: %.0fs', remaining), ...
            'BackgroundColor',[1 1 0.7],'FontWeight','bold','FontSize',12);
    end

    % ==========================================================
    % TAB 2 - ADVANCED
    % ==========================================================
    ax5 = subplot(2,2,1,'Parent',parent2);
    if isfield(results,'rdMap') && ~isempty(results.rdMap)
        imagesc(ax5, 20*log10(results.rdMap+eps));
        xlabel(ax5,'Doppler Bin'); ylabel(ax5,'Range Bin');
        title(ax5,'Range–Doppler Map (last snapshot, dB)');
        colorbar(ax5);
    else
        text(ax5,0.5,0.5,'No Range-Doppler data','HorizontalAlignment','center');
        axis(ax5,'off');
    end

    ax6 = subplot(2,2,2,'Parent',parent2);
    if isfield(results,'snr')
        plot(ax6, results.time, results.snr,'r-','LineWidth',1.5); hold(ax6,'on');
        yline(ax6,params.snrThreshold,'--k','SNR Thresh');
        grid(ax6,'on'); xlabel(ax6,'Time (s)'); ylabel(ax6,'SNR (dB)');
        title(ax6,'SNR Over Time');
    end

    ax7 = subplot(2,2,3,'Parent',parent2);
    if isfield(results,'cfarMaskHist') && ~isempty(results.cfarMaskHist)
        imagesc(ax7, results.cfarMaskHist); colormap(ax7,'hot');
        xlabel(ax7,'Range Bin'); ylabel(ax7,'Time Step');
        title(ax7,'CFAR Detections');
    else
        text(ax7,0.5,0.5,'CFAR disabled','HorizontalAlignment','center'); axis(ax7,'off');
    end

    ax8 = subplot(2,2,4,'Parent',parent2);
    if isfield(results,'forecastLevel')
        plot(ax8,results.time, results.waterLevel,'b-','LineWidth',1.5); hold(ax8,'on');
        plot(ax8,results.time, results.forecastLevel,'g--','LineWidth',1.5);
        yline(ax8,params.levelFlood,'--r','Flood');
        legend(ax8,{'Measured','Forecast','Flood Thr'},'Location','best');
        xlabel(ax8,'Time (s)'); ylabel(ax8,'Water Level (m)');
        title(ax8,'ARIMA/Linear Forecast vs Measured'); grid(ax8,'on');
    end

    % ==========================================================
    % TAB 3 - STATISTICS & RISK
    % ==========================================================
    ax9 = subplot(2,2,1,'Parent',parent3);
    if isfield(results,'riskProb')
        plot(ax9, results.time, results.riskProb,'m-','LineWidth',1.8); hold(ax9,'on');
        ylim(ax9,[0 1]); grid(ax9,'on');
        xlabel(ax9,'Time (s)'); ylabel(ax9,'P(Flood)');
        title(ax9,'Risk Probability Curve');
    end

    ax10 = subplot(2,2,2,'Parent',parent3);
    if isfield(results,'rangeProfile')
        mu = mean(results.rangeProfile); sig = std(results.rangeProfile);
        pk = max(results.rangeProfile);
        bar(ax10,[mu sig pk]);
        xticklabels(ax10,{'Mean','Std','Peak'});
        title(ax10,'Range Profile Stats'); grid(ax10,'on');
    end

    ax11 = subplot(2,2,3,'Parent',parent3);
    if isfield(results,'roc') && ~isempty(results.roc)
        plot(ax11, results.roc.Pfa, results.roc.Pd, 'b-o','LineWidth',1.5);
        xlabel(ax11,'P_{FA}'); ylabel(ax11,'P_D');
        title(ax11,'ROC Curve (Monte Carlo)'); grid(ax11,'on');
        xlim(ax11,[0 1]); ylim(ax11,[0 1]);
    else
        text(ax11,0.5,0.5,'Run Monte Carlo for ROC','HorizontalAlignment','center'); axis(ax11,'off');
    end

    ax12 = subplot(2,2,4,'Parent',parent3);
    if isfield(results,'time')
        wl = results.waterLevel;
        text(ax12,0.05,0.9,sprintf('Final Status : %s', results.finalStatus),'FontSize',14,'FontWeight','bold');
        text(ax12,0.05,0.75,sprintf('Max Level : %.2f m', max(wl)),'FontSize',12);
        text(ax12,0.05,0.60,sprintf('Mean Level : %.2f m', mean(wl)),'FontSize',12);
        text(ax12,0.05,0.45,sprintf('Duration  : %.0f s', results.time(end)),'FontSize',12);
        text(ax12,0.05,0.30,sprintf('Scenario  : %s', getfield_or(params,'scenario','?')),'FontSize',12);
        axis(ax12,'off');
    end

    % Export button -------------------------------------------
    uicontrol(fig,'Style','pushbutton','String','Export PDF Report', ...
              'Units','normalized','Position',[0.85 0.01 0.13 0.04], ...
              'BackgroundColor',[0.8 1 0.8],'FontWeight','bold', ...
              'Callback',@(s,e)export_report(results,params,fig));

    sgtitle(fig,'Flood Monitoring Radar - Enhanced Dashboard','FontSize',14,'FontWeight','bold');
    figHandles = fig;
    disp('[dashboard] rendered.');
    disp(['Final Status: ' results.finalStatus]);
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
