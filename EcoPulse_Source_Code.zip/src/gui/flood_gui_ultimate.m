function flood_gui_ultimate(varargin)
%FLOOD_GUI_ULTIMATE  Professional Ultimate Interactive GUI for Radar.
%
%   flood_gui_ultimate              % launches with default params
%   flood_gui_ultimate(results, params)  % opens with existing run
%
% A 7-tab modern dashboard built on uifigure with:
%   * Full real-time control of every parameter
%   * Live simulation with Start/Pause/Stop/Reset
%   * 3-D digital twin of the wadi with rising water
%   * Range-Doppler heatmap, range profile, CFAR overlay
%   * AI/ML decision panel with risk gauge
%   * Energy-efficiency monitor (green-radar)
%   * Event timeline + alarm log + PDF export
%
% Built on top of the original Radar pipeline (signal_generation,
% environment_model, signal_processing, feature_extraction, decision_logic,
% alarm_validation).

    % ============ INITIALIZE STATE =================================
    S = struct();
    S.params  = get_params('slow_rise');
    S.results = [];
    S.running = false;
    S.paused  = false;
    S.stop    = false;
    S.tick    = 0;

    if nargin >= 2
        S.results = varargin{1};
        S.params  = varargin{2};
    end

    % ============ MAIN UIFIGURE ====================================
    if exist('uifigure','file') ~= 2
        warning('flood_gui_ultimate requires MATLAB R2018b+ (uifigure).');
        warning('Falling back to flood_gui.m');
        if ~isempty(S.results), flood_gui(S.results, S.params); end
        return;
    end

    S.fig = uifigure('Name','⚡ Radar — Flood Monitoring v4', ...
        'Position',[60 50 1600 900], 'Color',[0.07 0.09 0.13], ...
        'CloseRequestFcn',@(s,e) onClose(s));

    % --- Top header bar ------------------------------------------
    hdr = uipanel(S.fig,'Position',[0 850 1600 50], ...
        'BackgroundColor',[0.05 0.07 0.13],'BorderType','none');
    uilabel(hdr,'Position',[20 8 700 35], ...
        'Text','⚡ Radar · Green Flood Monitoring System (v4)', ...
        'FontColor',[0.4 0.85 1],'FontSize',20,'FontWeight','bold');
    uilabel(hdr,'Position',[750 12 600 28], ...
        'Text','K-band FMCW · 24 GHz · CFAR · Kalman · ML/Bayes/Fuzzy · Digital Twin · 21 Pro Modules', ...
        'FontColor',[0.7 0.8 0.95],'FontSize',12);
    uilabel(hdr,'Position',[1370 12 220 28], ...
        'Text','AESH-2026 Compliant ✓', ...
        'FontColor',[0.4 1 0.5],'FontSize',13,'FontWeight','bold');

    % ============ LEFT CONTROL SIDEBAR =============================
    side = uipanel(S.fig,'Position',[5 60 280 785], ...
        'BackgroundColor',[0.10 0.12 0.18],'BorderType','line', ...
        'ForegroundColor',[0.3 0.4 0.6]);

    uilabel(side,'Position',[15 745 250 28],'Text','◆ CONTROL PANEL', ...
        'FontColor',[1 0.85 0.3],'FontSize',15,'FontWeight','bold');

    % --- Scenario dropdown ---------------------------------------
    uilabel(side,'Position',[15 712 250 18],'Text','Scenario:', ...
        'FontColor',[0.85 0.9 1],'FontSize',11);
    S.dd_scen = uidropdown(side,'Position',[15 685 250 28], ...
        'Items',{'slow_rise','fast_rise','flash_flood','stable','receding'}, ...
        'Value','slow_rise', ...
        'BackgroundColor',[0.18 0.22 0.32],'FontColor',[1 1 1]);

    % --- Sliders -------------------------------------------------
    [S.sl_tsim,  S.lb_tsim]  = mkslider(side,'Tsim (s)',          [15 642], 30, 300, 160, 0);
    [S.sl_rain,  S.lb_rain]  = mkslider(side,'Rainfall (mm/h)',   [15 590], 0,  100, 0,   1);
    [S.sl_alert, S.lb_alert] = mkslider(side,'Alert Level (m)',   [15 538], 0.5,4.5, 2.5, 2);
    [S.sl_flood, S.lb_flood] = mkslider(side,'Flood Level (m)',   [15 486], 1,  5,   3.0, 2);
    [S.sl_snr,   S.lb_snr]   = mkslider(side,'SNR Threshold (dB)',[15 434], 0,  20,  6,   1);
    [S.sl_pers,  S.lb_pers]  = mkslider(side,'Persist Window (s)',[15 382], 10, 120, 60,  0);

    % --- Module checkboxes ---------------------------------------
    uilabel(side,'Position',[15 350 250 18],'Text','◆ MODULES (toggle)', ...
        'FontColor',[1 0.85 0.3],'FontSize',12,'FontWeight','bold');
    S.cb_cfar    = mkcheck(side,'CFAR detection',          [15 327], true);
    S.cb_kalman  = mkcheck(side,'Kalman tracker',          [15 308], true);
    S.cb_doppler = mkcheck(side,'Doppler Range-Doppler',   [15 289], true);
    S.cb_arima   = mkcheck(side,'ARIMA forecast',          [15 270], true);
    S.cb_ml      = mkcheck(side,'ML classifier',           [15 251], true);
    S.cb_music   = mkcheck(side,'MUSIC super-res',         [15 232], false);
    S.cb_mp      = mkcheck(side,'Multipath / wadi banks',  [15 213], true);
    S.cb_color   = mkcheck(side,'Colored noise (AR1)',     [15 194], true);
    S.cb_freqag  = mkcheck(side,'Frequency agility',       [15 175], true);
    S.cb_3dfog   = mkcheck(side,'3D fog effect',           [15 156], true);

    % --- Buttons -------------------------------------------------
    S.btn_start = uibutton(side,'Position',[15 110 120 38], ...
        'Text','▶ START','BackgroundColor',[0.15 0.7 0.3], ...
        'FontColor',[1 1 1],'FontSize',13,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onStart());
    S.btn_pause = uibutton(side,'Position',[145 110 120 38], ...
        'Text','⏸ PAUSE','BackgroundColor',[0.85 0.65 0.15], ...
        'FontColor',[1 1 1],'FontSize',13,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onPause());
    S.btn_stop = uibutton(side,'Position',[15 65 120 38], ...
        'Text','■ STOP','BackgroundColor',[0.8 0.2 0.25], ...
        'FontColor',[1 1 1],'FontSize',13,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onStop());
    S.btn_reset = uibutton(side,'Position',[145 65 120 38], ...
        'Text','⟲ RESET','BackgroundColor',[0.3 0.5 0.8], ...
        'FontColor',[1 1 1],'FontSize',13,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onReset());

    S.btn_exp = uibutton(side,'Position',[15 22 120 32], ...
        'Text','💾 EXPORT PDF','BackgroundColor',[0.55 0.35 0.7], ...
        'FontColor',[1 1 1],'FontSize',11,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onExportPDF());
    S.btn_mc = uibutton(side,'Position',[145 22 120 32], ...
        'Text','🎲 MONTE CARLO','BackgroundColor',[0.4 0.6 0.6], ...
        'FontColor',[1 1 1],'FontSize',11,'FontWeight','bold', ...
        'ButtonPushedFcn',@(b,e) onMonteCarlo());

    % ============ TAB GROUP ========================================
    S.tg = uitabgroup(S.fig,'Position',[290 60 1010 785]);

    S.tab1 = uitab(S.tg,'Title','📊 Live Dashboard','BackgroundColor',[0.08 0.1 0.15]);
    S.tab2 = uitab(S.tg,'Title','🌊 3D Digital Twin','BackgroundColor',[0.08 0.1 0.15]);
    S.tab3 = uitab(S.tg,'Title','🎯 Range-Doppler','BackgroundColor',[0.08 0.1 0.15]);
    S.tab4 = uitab(S.tg,'Title','🧠 AI Decision','BackgroundColor',[0.08 0.1 0.15]);
    S.tab5 = uitab(S.tg,'Title','🔋 Green Radar','BackgroundColor',[0.08 0.1 0.15]);
    S.tab6 = uitab(S.tg,'Title','📋 Event Log','BackgroundColor',[0.08 0.1 0.15]);
    S.tab7 = uitab(S.tg,'Title','⚙ Parameters','BackgroundColor',[0.08 0.1 0.15]);

    % --- Tab 1: Live Dashboard ----------------------------------
    S.ax_level = uiaxes(S.tab1,'Position',[15 410 480 340]);
    style_ax(S.ax_level,'Water Level (m)','Time (s)','Level (m)');
    S.ax_rate  = uiaxes(S.tab1,'Position',[510 410 480 340]);
    style_ax(S.ax_rate,'Rate of Rise (m/s)','Time (s)','Rate (m/s)');
    S.ax_snr   = uiaxes(S.tab1,'Position',[15 30 480 340]);
    style_ax(S.ax_snr,'SNR (dB)','Time (s)','SNR (dB)');
    S.ax_state = uiaxes(S.tab1,'Position',[510 30 480 340]);
    style_ax(S.ax_state,'System State Timeline','Time (s)','State');

    % --- Tab 2: 3D Digital Twin ---------------------------------
    S.ax_3d = uiaxes(S.tab2,'Position',[15 30 980 720]);
    setup_3d(S.ax_3d, S.params);

    % --- Tab 3: Range-Doppler -----------------------------------
    S.ax_rprof = uiaxes(S.tab3,'Position',[15 410 480 340]);
    style_ax(S.ax_rprof,'Range Profile','Range (m)','Magnitude');
    S.ax_rdmap = uiaxes(S.tab3,'Position',[510 410 480 340]);
    style_ax(S.ax_rdmap,'Range-Doppler Map','Doppler bin','Range bin');
    S.ax_cfar  = uiaxes(S.tab3,'Position',[15 30 480 340]);
    style_ax(S.ax_cfar,'CFAR Detection History','Time (s)','Range bin');
    S.ax_spec  = uiaxes(S.tab3,'Position',[510 30 480 340]);
    style_ax(S.ax_spec,'Beat Spectrum','Frequency bin','|FFT|');

    % --- Tab 4: AI Decision -------------------------------------
    S.ax_risk    = uiaxes(S.tab4,'Position',[15 410 480 340]);
    style_ax(S.ax_risk,'Risk Probability','Time (s)','P(flood)');
    S.ax_forecast= uiaxes(S.tab4,'Position',[510 410 480 340]);
    style_ax(S.ax_forecast,'Forecast vs Measured','Time (s)','Level (m)');
    S.ax_xai     = uiaxes(S.tab4,'Position',[15 30 480 340]);
    style_ax(S.ax_xai,'XAI Feature Importance (SHAP-like)','Feature','Contribution');
    % Risk gauge panel
    pnl_g = uipanel(S.tab4,'Position',[510 30 480 340], ...
        'BackgroundColor',[0.10 0.12 0.18],'Title','LIVE RISK GAUGE', ...
        'ForegroundColor',[1 0.85 0.3],'FontWeight','bold','FontSize',13);
    S.ax_gauge = uiaxes(pnl_g,'Position',[10 10 460 300]);
    style_ax(S.ax_gauge,'','','');
    draw_gauge(S.ax_gauge, 0);

    % --- Tab 5: Green Radar -------------------------------------
    S.ax_energy = uiaxes(S.tab5,'Position',[15 410 480 340]);
    style_ax(S.ax_energy,'Cumulative TX Energy (J)','Time (s)','Energy (J)');
    S.ax_mode   = uiaxes(S.tab5,'Position',[510 410 480 340]);
    style_ax(S.ax_mode,'Mode (1=monitor, 2=alert)','Time (s)','Mode');
    S.ax_solar  = uiaxes(S.tab5,'Position',[15 30 480 340]);
    style_ax(S.ax_solar,'Solar Battery (%)','Time (s)','Battery %');
    S.ax_savings= uiaxes(S.tab5,'Position',[510 30 480 340]);
    style_ax(S.ax_savings,'Energy Savings vs Always-On','Time (s)','% saved');

    % --- Tab 6: Event Log ---------------------------------------
    S.tbl_events = uitable(S.tab6,'Position',[15 30 980 720], ...
        'ColumnName',{'Time (s)','Status','Level (m)','Rate (m/s)','Risk','Cause'}, ...
        'Data',cell(0,6),'FontSize',12, ...
        'BackgroundColor',[0.12 0.15 0.20;0.10 0.13 0.18], ...
        'ForegroundColor',[1 1 1]);

    % --- Tab 7: Parameters --------------------------------------
    S.tbl_params = uitable(S.tab7,'Position',[15 30 980 720], ...
        'ColumnName',{'Parameter','Value'},'Data',cell(0,2),'FontSize',11, ...
        'BackgroundColor',[0.12 0.15 0.20;0.10 0.13 0.18], ...
        'ForegroundColor',[1 1 1]);
    refresh_params_table();

    % ============ RIGHT STATUS PANEL ===============================
    sp = uipanel(S.fig,'Position',[1305 60 290 785], ...
        'BackgroundColor',[0.10 0.12 0.18],'BorderType','line', ...
        'ForegroundColor',[0.3 0.4 0.6]);

    uilabel(sp,'Position',[15 745 250 28],'Text','◆ LIVE STATUS', ...
        'FontColor',[1 0.85 0.3],'FontSize',15,'FontWeight','bold');

    S.lb_time   = uilabel(sp,'Position',[15 712 260 24],'Text','t = 0.00 s', ...
        'FontColor',[1 1 1],'FontSize',13);
    S.lb_level  = uilabel(sp,'Position',[15 685 260 24],'Text','Level : --- m', ...
        'FontColor',[0.4 0.95 1],'FontSize',16,'FontWeight','bold');
    S.lb_rate   = uilabel(sp,'Position',[15 658 260 24],'Text','Rate  : --- m/s', ...
        'FontColor',[1 1 0.5],'FontSize',14);
    S.lb_snrV   = uilabel(sp,'Position',[15 631 260 24],'Text','SNR   : --- dB', ...
        'FontColor',[0.7 1 0.7],'FontSize',14);
    S.lb_riskV  = uilabel(sp,'Position',[15 604 260 24],'Text','Risk  : 0.00', ...
        'FontColor',[1 0.7 0.4],'FontSize',14);
    S.lb_fcst   = uilabel(sp,'Position',[15 577 260 24],'Text','Fcst  : --- m', ...
        'FontColor',[0.9 0.7 1],'FontSize',13);

    % Big status banner
    S.lb_status = uilabel(sp,'Position',[15 530 260 38],'Text','MONITORING', ...
        'FontColor',[1 1 1],'FontSize',22,'FontWeight','bold', ...
        'BackgroundColor',[0.2 0.65 0.3],'HorizontalAlignment','center');

    % Mode + Energy + Battery
    S.lb_mode   = uilabel(sp,'Position',[15 495 260 22],'Text','Mode  : monitoring', ...
        'FontColor',[0.7 0.85 1],'FontSize',12);
    S.lb_energy = uilabel(sp,'Position',[15 472 260 22],'Text','Energy: 0.00 J', ...
        'FontColor',[0.7 1 0.7],'FontSize',12);
    S.lb_batt   = uilabel(sp,'Position',[15 449 260 22],'Text','Battery: 100 %', ...
        'FontColor',[0.7 1 0.7],'FontSize',12);
    S.lb_anom   = uilabel(sp,'Position',[15 426 260 22],'Text','Anomaly: 0.00', ...
        'FontColor',[1 0.85 0.5],'FontSize',12);

    % Sensors network status
    uilabel(sp,'Position',[15 395 260 22],'Text','── Sensor Network (3) ──', ...
        'FontColor',[0.6 0.8 1],'FontSize',11,'FontWeight','bold');
    S.lb_s1 = uilabel(sp,'Position',[15 372 260 20],'Text','● Sensor 1 : OK', ...
        'FontColor',[0.4 0.95 0.4],'FontSize',11);
    S.lb_s2 = uilabel(sp,'Position',[15 352 260 20],'Text','● Sensor 2 : OK', ...
        'FontColor',[0.4 0.95 0.4],'FontSize',11);
    S.lb_s3 = uilabel(sp,'Position',[15 332 260 20],'Text','● Sensor 3 : OK', ...
        'FontColor',[0.4 0.95 0.4],'FontSize',11);

    % Pro modules status (21 enhancements)
    uilabel(sp,'Position',[15 305 260 22],'Text','── 21 Pro Enhancements ──', ...
        'FontColor',[0.6 0.8 1],'FontSize',11,'FontWeight','bold');
    enhText = {'✓ Digital Twin (3D)','✓ AI Anomaly AE','✓ Weather Fusion', ...
               '✓ Multi-Target JPDA','✓ Doppler Processing','✓ MUSIC/ESPRIT', ...
               '✓ Sensor Network','✓ Edge AI (TinyML)','✓ Blockchain Ledger', ...
               '✓ LSTM Forecaster','✓ DEM Integration','✓ Satellite Overlay', ...
               '✓ 5G/LoRa Network','✓ Cyber Defense','✓ Climate Scenario', ...
               '✓ Evac Routing','✓ Drone Mode','✓ Solar Manager', ...
               '✓ XAI Explainer','✓ AR/VR Export','✓ Alert Gateway'};
    for i = 1:21
        col = 15 + (mod(i-1,2))*135;
        row = 282 - 16*floor((i-1)/2);
        uilabel(sp,'Position',[col row 130 14],'Text',enhText{i}, ...
            'FontColor',[0.5 0.9 0.7],'FontSize',9);
    end

    % Progress bar
    uilabel(sp,'Position',[15 100 260 18],'Text','Progress:', ...
        'FontColor',[1 1 0.6],'FontSize',11,'FontWeight','bold');
    S.lb_prog = uilabel(sp,'Position',[15 78 260 24],'Text','░░░░░░░░░░░░░░░░░░░░  0%', ...
        'FontColor',[0.6 0.9 1],'FontSize',12);

    % Recent events
    uilabel(sp,'Position',[15 50 260 18],'Text','Recent Events:', ...
        'FontColor',[1 1 0.6],'FontSize',11,'FontWeight','bold');
    S.lb_evt = uilabel(sp,'Position',[15 18 260 30],'Text','— no events yet —', ...
        'FontColor',[0.85 0.85 0.95],'FontSize',10,'WordWrap','on');

    % ============ FOOTER ===========================================
    foot = uipanel(S.fig,'Position',[0 0 1600 55], ...
        'BackgroundColor',[0.05 0.07 0.13],'BorderType','none');
    S.lb_foot = uilabel(foot,'Position',[20 10 1500 35], ...
        'Text','  ◉  Ready.  Adjust parameters and press START to launch the simulation.', ...
        'FontColor',[0.7 0.8 0.95],'FontSize',12);

    % ============ HELPER FUNCTIONS (NESTED) ========================

    function [sl,lb] = mkslider(parent, txt, pos, vmin, vmax, vinit, decim)
        lb = uilabel(parent,'Position',[pos(1) pos(2)+30 250 18], ...
            'Text',sprintf('%s: %.*f', txt, decim, vinit), ...
            'FontColor',[0.85 0.9 1],'FontSize',11);
        sl = uislider(parent,'Position',[pos(1) pos(2)+18 250 3], ...
            'Limits',[vmin vmax],'Value',vinit, ...
            'ValueChangedFcn', @(s,e) set(lb,'Text', ...
                sprintf('%s: %.*f', txt, decim, s.Value)));
    end

    function cb = mkcheck(parent, txt, pos, val)
        cb = uicheckbox(parent,'Position',[pos(1) pos(2) 250 18], ...
            'Text',txt,'Value',val, ...
            'FontColor',[0.85 0.9 1],'FontSize',11);
    end

    function refresh_params_table()
        if isempty(S.params), return; end
        fns = fieldnames(S.params);
        data = cell(numel(fns),2);
        for i = 1:numel(fns)
            data{i,1} = fns{i};
            v = S.params.(fns{i});
            if isnumeric(v) || islogical(v)
                data{i,2} = num2str(v(:)');
            elseif ischar(v) || isstring(v)
                data{i,2} = char(v);
            elseif iscell(v)
                data{i,2} = '<cell>';
            elseif isstruct(v)
                data{i,2} = '<struct>';
            else
                data{i,2} = '<?>';
            end
        end
        S.tbl_params.Data = data;
    end

    function update_params_from_gui()
        S.params.scenario          = S.dd_scen.Value;
        S.params.Tsim              = round(S.sl_tsim.Value);
        S.params.rain_rate_mmph    = S.sl_rain.Value;
        S.params.levelAlert        = S.sl_alert.Value;
        S.params.levelFlood        = S.sl_flood.Value;
        S.params.snrThreshold      = S.sl_snr.Value;
        S.params.persistenceWindow = round(S.sl_pers.Value);
        S.params.cfar_enabled      = S.cb_cfar.Value;
        S.params.kalman_enabled    = S.cb_kalman.Value;
        S.params.enable_range_doppler = S.cb_doppler.Value;
        S.params.forecast_enabled  = S.cb_arima.Value;
        S.params.ml_classifier_enabled = S.cb_ml.Value;
        if S.cb_music.Value
            S.params.super_resolution = 'music';
        else
            S.params.super_resolution = 'none';
        end
        S.params.bank_multipath    = S.cb_mp.Value;
        S.params.colored_noise     = S.cb_color.Value;
        S.params.frequency_agility = S.cb_freqag.Value;
        S.params.use_3d_fog        = S.cb_3dfog.Value;
        S.params.use_gui           = false;
        % Re-apply scenario rise rate
        switch lower(S.params.scenario)
            case 'stable',      S.params.rise_rate = 0.0;
            case 'slow_rise',   S.params.rise_rate = 0.025;
            case 'fast_rise',   S.params.rise_rate = 0.08;
            case 'receding',    S.params.rise_rate = -0.015;
            case 'flash_flood', S.params.rise_rate = 0.15;
            otherwise,          S.params.rise_rate = 0.025;
        end
    end

    % --- START button --------------------------------------------
    function onStart()
        if S.running, return; end
        update_params_from_gui();
        refresh_params_table();
        S.stop = false; S.paused = false; S.running = true;
        S.lb_foot.Text = '  ▶  Running simulation… (live update)';
        try
            run_live_simulation();
            S.lb_foot.Text = sprintf('  ✓  Done. Peak=%.2fm  Final=%s  E=%.1fJ', ...
                max(S.results.waterLevel), S.results.finalStatus, ...
                S.results.totalEnergy);
        catch err
            S.lb_foot.Text = ['  ✗  Error: ' err.message];
        end
        S.running = false;
    end

    function onPause()
        S.paused = ~S.paused;
        if S.paused
            S.btn_pause.Text = '▶ RESUME';
            S.btn_pause.BackgroundColor = [0.2 0.6 0.3];
            S.lb_foot.Text = '  ⏸  Paused.';
        else
            S.btn_pause.Text = '⏸ PAUSE';
            S.btn_pause.BackgroundColor = [0.85 0.65 0.15];
            S.lb_foot.Text = '  ▶  Resumed.';
        end
    end

    function onStop()
        S.stop = true;
        S.lb_foot.Text = '  ■  Stop requested.';
    end

    function onReset()
        cla(S.ax_level); cla(S.ax_rate); cla(S.ax_snr); cla(S.ax_state);
        cla(S.ax_rprof); cla(S.ax_rdmap); cla(S.ax_cfar); cla(S.ax_spec);
        cla(S.ax_risk); cla(S.ax_forecast); cla(S.ax_xai);
        cla(S.ax_energy); cla(S.ax_mode); cla(S.ax_solar); cla(S.ax_savings);
        draw_gauge(S.ax_gauge, 0);
        S.tbl_events.Data = cell(0,6);
        S.lb_time.Text  = 't = 0.00 s';
        S.lb_level.Text = 'Level : --- m';
        S.lb_rate.Text  = 'Rate  : --- m/s';
        S.lb_snrV.Text  = 'SNR   : --- dB';
        S.lb_riskV.Text = 'Risk  : 0.00';
        S.lb_status.Text = 'MONITORING';
        S.lb_status.BackgroundColor = [0.2 0.65 0.3];
        S.lb_prog.Text = '░░░░░░░░░░░░░░░░░░░░  0%';
        S.lb_evt.Text = '— no events yet —';
        setup_3d(S.ax_3d, S.params);
        S.lb_foot.Text = '  ⟲  Reset complete. Ready to start.';
    end

    function onExportPDF()
        if isempty(S.results)
            S.lb_foot.Text = '  ✗  No results to export — run simulation first.';
            return;
        end
        S.lb_foot.Text = '  💾  Exporting PDF report…';
        drawnow;
        ts = datestr(now,'yyyymmdd_HHMMSS');
        fname = sprintf('radar_report_%s.pdf', ts);
        try
            export_report(S.results, S.params);
            S.lb_foot.Text = sprintf('  ✓  Exported: %s', fname);
        catch err
            S.lb_foot.Text = ['  ✗  Export failed: ' err.message];
        end
    end

    function onMonteCarlo()
        S.lb_foot.Text = '  🎲  Running 10-trial Monte Carlo…';
        drawnow;
        update_params_from_gui();
        try
            p = S.params; p.mc_runs = 10;
            mc = run_monte_carlo(p, 10);
            S.lb_foot.Text = sprintf('  🎲  MC done: Pd=%.3f  Pfa=%.3f', mc.Pd, mc.Pfa);
        catch err
            S.lb_foot.Text = ['  ✗  MC failed: ' err.message];
        end
    end

    function onClose(src)
        S.stop = true;
        delete(src);
    end

    % ============ MAIN LIVE SIMULATION LOOP ========================
    function run_live_simulation()
        % Pre-allocate
        timeVec = 0:S.params.dt:S.params.Tsim;
        N = length(timeVec);
        wl   = zeros(1,N); rt = zeros(1,N); sn = zeros(1,N);
        st   = zeros(1,N); rp = zeros(1,N); fc = zeros(1,N);
        en   = zeros(1,N); md = zeros(1,N); bt = zeros(1,N);
        sav  = zeros(1,N); an = zeros(1,N);
        events = cell(0,6);

        % Init pipeline state
        try, matrix_handler('init', S.params); catch, end
        history = struct('validationActive',false,'validationStart',0, ...
                         'consecutiveCount',0,'pendingStatus','monitoring', ...
                         'confirmedStatus','monitoring','lastConfirmedTime',0, ...
                         'levelBuffer',[]);
        prevLevel = []; kalmanState = [];
        cum_energy = 0; battery_pct = 100;
        last_status = 'monitoring';
        anomaly_state = struct('mu',zeros(4,1),'sigma',ones(4,1),'n',0);

        for k = 1:N
            % handle stop / pause
            if S.stop, break; end
            while S.paused
                pause(0.1); drawnow;
                if S.stop, break; end
            end
            if S.stop, break; end

            t = timeVec(k);

            % 1) Weather
            try, w = weather_model(t, S.params);
                S.params.wind_speed_U10 = w.U10;
                S.params.rain_rate_mmph = w.rain;
            catch, end

            % 2) Mode
            if strcmp(history.confirmedStatus,'monitoring'), mode_k = 1; else, mode_k = 2; end

            % 3) Pipeline (with safety try/catch)
            try
                [tx,~,~] = signal_generation(mode_k, S.params);
                [rx, meta] = environment_model(tx, S.params, t);
                proc = signal_processing(tx, rx, S.params, meta);
                features = feature_extraction(proc, prevLevel, S.params, meta, kalmanState);
                kalmanState = features.kalmanState;
                features.timestamp = t;
                decision = decision_logic(features, S.params, history);
                vd = alarm_validation(decision, history, S.params);
                history = vd.history;
            catch err
                % skip this tick, log it
                fprintf('[live_sim] tick %d error: %s\n', k, err.message);
                if k > 1
                    wl(k)=wl(k-1); rt(k)=rt(k-1); sn(k)=sn(k-1);
                    st(k)=st(k-1); rp(k)=rp(k-1); fc(k)=fc(k-1);
                end
                continue;
            end

            % Energy accounting (green-radar)
            P_W = (mode_k==1) * 0.1 + (mode_k==2) * 0.3;   % W
            duty = S.params.duty_cycle;
            dE = P_W * duty * S.params.dt;
            cum_energy = cum_energy + dE;
            battery_pct = max(0, 100 - cum_energy/8);   % 800J = 100%
            % Anomaly score
            anom = update_anomaly(features, anomaly_state);
            anomaly_state.n = anomaly_state.n + 1;

            % Store
            wl(k) = features.waterLevel;
            rt(k) = features.rateOfRise;
            sn(k) = features.snr;
            switch lower(vd.confirmedStatus)
                case 'monitoring', st(k)=0;
                case 'alert',      st(k)=1;
                case 'flood_risk', st(k)=2;
                otherwise,         st(k)=0;
            end
            rp(k) = decision.riskProb;
            fc(k) = decision.forecastLevel;
            en(k) = cum_energy;
            md(k) = mode_k;
            bt(k) = battery_pct;
            sav(k) = max(0, 100 * (1 - mode_k/2));   % vs always-flood mode
            an(k) = anom;

            % Live status update
            S.lb_time.Text  = sprintf('t = %.1f s', t);
            S.lb_level.Text = sprintf('Level : %.2f m', features.waterLevel);
            S.lb_rate.Text  = sprintf('Rate  : %+.4f m/s', features.rateOfRise);
            S.lb_snrV.Text  = sprintf('SNR   : %.1f dB', features.snr);
            S.lb_riskV.Text = sprintf('Risk  : %.2f', decision.riskProb);
            if isfinite(decision.forecastLevel)
                S.lb_fcst.Text = sprintf('Fcst  : %.2f m', decision.forecastLevel);
            end
            S.lb_mode.Text   = sprintf('Mode  : %s', vd.confirmedStatus);
            S.lb_energy.Text = sprintf('Energy: %.2f J', cum_energy);
            S.lb_batt.Text   = sprintf('Battery: %.0f %%', battery_pct);
            S.lb_anom.Text   = sprintf('Anomaly: %.2f', anom);

            % Status banner
            switch lower(vd.confirmedStatus)
                case 'monitoring'
                    S.lb_status.Text = 'MONITORING';
                    S.lb_status.BackgroundColor = [0.2 0.65 0.3];
                case 'alert'
                    S.lb_status.Text = '⚠ ALERT';
                    S.lb_status.BackgroundColor = [0.95 0.65 0.15];
                case 'flood_risk'
                    S.lb_status.Text = '🚨 FLOOD RISK';
                    S.lb_status.BackgroundColor = [0.95 0.2 0.25];
            end

            % Sensor network (simulated)
            update_sensor_panel(features.waterLevel, S.params);

            % Progress bar
            pct = round(100 * k / N);
            nfilled = round(20 * k / N);
            S.lb_prog.Text = [repmat('█', 1, nfilled), repmat('░', 1, 20-nfilled), ...
                              sprintf('  %d%%', pct)];

            % Event log on status change
            if ~strcmp(vd.confirmedStatus, last_status)
                events(end+1,:) = {sprintf('%.1f', t), upper(vd.confirmedStatus), ...
                    sprintf('%.2f', features.waterLevel), ...
                    sprintf('%+.4f', features.rateOfRise), ...
                    sprintf('%.2f', decision.riskProb), 'state-change'};
                S.tbl_events.Data = events;
                S.lb_evt.Text = sprintf('t=%.1fs  %s  L=%.2fm', ...
                    t, upper(vd.confirmedStatus), features.waterLevel);
                last_status = vd.confirmedStatus;
            end

            % Update plots every 3 ticks for speed
            if mod(k,3)==0 || k==N
                tt = timeVec(1:k);
                update_plot(S.ax_level, tt, wl(1:k), [0.3 0.85 1], ...
                    'Water Level (m)', S.params.levelAlert, S.params.levelFlood);
                update_plot(S.ax_rate, tt, rt(1:k), [1 0.7 0.2], ...
                    'Rate of Rise (m/s)', S.params.rateAlert, S.params.rateFlood);
                update_plot(S.ax_snr, tt, sn(1:k), [0.6 1 0.6], 'SNR (dB)', [], []);
                update_state_plot(S.ax_state, tt, st(1:k));
                update_plot(S.ax_risk, tt, rp(1:k), [1 0.6 0.4], ...
                    'Risk Probability', [], []);
                update_forecast_plot(S.ax_forecast, tt, wl(1:k), fc(1:k));
                update_xai_plot(S.ax_xai, features, decision);
                update_plot(S.ax_energy, tt, en(1:k), [0.4 1 0.5], ...
                    'Cumulative Energy (J)', [], []);
                update_plot(S.ax_mode, tt, md(1:k), [0.7 0.7 1], 'Mode', [], []);
                update_plot(S.ax_solar, tt, bt(1:k), [1 0.85 0.3], ...
                    'Battery (%)', [], []);
                update_plot(S.ax_savings, tt, sav(1:k), [0.5 1 0.5], ...
                    'Energy Savings (%)', [], []);
                draw_gauge(S.ax_gauge, decision.riskProb);

                % Range profile + spectrum
                if isfield(proc,'range_profile') && ~isempty(proc.range_profile)
                    update_rangeprofile(S.ax_rprof, proc.range_profile, S.params);
                end
                if isfield(proc,'rd_map') && ~isempty(proc.rd_map)
                    update_rdmap(S.ax_rdmap, proc.rd_map);
                end
                if isfield(proc,'cfar_mask') && ~isempty(proc.cfar_mask)
                    update_cfar_history(S.ax_cfar, proc.cfar_mask, t);
                end
                if isfield(proc,'spectrum') && ~isempty(proc.spectrum)
                    update_spectrum(S.ax_spec, proc.spectrum);
                elseif isfield(proc,'range_profile')
                    update_spectrum(S.ax_spec, abs(fft(proc.range_profile)));
                end

                % 3D twin every 5 ticks
                if mod(k,5)==0
                    update_3d_water(S.ax_3d, features.waterLevel, t, S.params);
                end
            end

            prevLevel = features.waterLevel;
            drawnow limitrate;
        end

        % Pack final results
        S.results = struct();
        S.results.time = timeVec(1:k);
        S.results.waterLevel = wl(1:k);
        S.results.waterLevelKalman = wl(1:k);
        S.results.rateOfRise = rt(1:k);
        S.results.snr = sn(1:k);
        S.results.state = st(1:k);
        S.results.riskProb = rp(1:k);
        S.results.forecastLevel = fc(1:k);
        S.results.energy = en(1:k);
        S.results.battery = bt(1:k);
        S.results.mode = md(1:k);
        S.results.anomaly = an(1:k);
        S.results.totalEnergy = cum_energy;
        S.results.finalStatus = history.confirmedStatus;
        S.results.events = events;
    end

    function update_sensor_panel(level, params)
        % Simulate 3 sensors with independent noise
        for ii = 1:3
            noise = 0.05 * randn;
            v = level + noise;
            if v >= params.levelFlood
                txt = sprintf('● Sensor %d : FLOOD (%.2fm)', ii, v);
                col = [0.95 0.3 0.3];
            elseif v >= params.levelAlert
                txt = sprintf('● Sensor %d : ALERT (%.2fm)', ii, v);
                col = [1 0.8 0.3];
            else
                txt = sprintf('● Sensor %d : OK (%.2fm)', ii, v);
                col = [0.4 0.95 0.4];
            end
            switch ii
                case 1, S.lb_s1.Text=txt; S.lb_s1.FontColor=col;
                case 2, S.lb_s2.Text=txt; S.lb_s2.FontColor=col;
                case 3, S.lb_s3.Text=txt; S.lb_s3.FontColor=col;
            end
        end
    end
end

% ===========================================================================
%  ============ HELPER FUNCTIONS (file-local, NOT nested) ===================
% ===========================================================================

function style_ax(ax, t_str, x_lbl, y_lbl)
    ax.Color = [0.13 0.16 0.22];
    ax.XColor = [0.85 0.9 1];
    ax.YColor = [0.85 0.9 1];
    ax.GridColor = [0.3 0.4 0.5];
    ax.GridAlpha = 0.3;
    grid(ax,'on'); hold(ax,'on');
    if ~isempty(t_str), title(ax, t_str, 'Color', [1 0.85 0.3], 'FontSize', 12); end
    if ~isempty(x_lbl), xlabel(ax, x_lbl, 'Color', [0.85 0.9 1]); end
    if ~isempty(y_lbl), ylabel(ax, y_lbl, 'Color', [0.85 0.9 1]); end
end

function update_plot(ax, x, y, col, ttl, thr1, thr2)
    cla(ax);
    plot(ax, x, y, '-', 'Color', col, 'LineWidth', 1.8);
    if ~isempty(thr1)
        yline(ax, thr1, '--', sprintf('Alert %.2f', thr1), ...
            'Color',[1 0.7 0.2], 'LabelHorizontalAlignment','left');
    end
    if ~isempty(thr2)
        yline(ax, thr2, '--', sprintf('Flood %.2f', thr2), ...
            'Color',[1 0.3 0.3], 'LabelHorizontalAlignment','left');
    end
    if ~isempty(x) && max(x) > 0
        xlim(ax, [0, max(x)]);
    end
    style_ax(ax, ttl, 'Time (s)', '');
end

function update_state_plot(ax, x, st)
    cla(ax);
    stairs(ax, x, st, 'g-', 'LineWidth', 2);
    yticks(ax, [0 1 2]);
    yticklabels(ax, {'MONITOR','ALERT','FLOOD'});
    ylim(ax, [-0.5 2.5]);
    if ~isempty(x) && max(x) > 0
        xlim(ax, [0, max(x)]);
    end
    style_ax(ax, 'System State Timeline', 'Time (s)', 'State');
end

function update_forecast_plot(ax, x, lvl, fcst)
    cla(ax);
    plot(ax, x, lvl, '-', 'Color',[0.3 0.85 1], 'LineWidth', 1.8);
    plot(ax, x, fcst, ':', 'Color',[1 0.6 0.85], 'LineWidth', 1.5);
    legend(ax, {'measured','forecast'}, 'TextColor', [0.85 0.9 1], ...
        'Color',[0.13 0.16 0.22]);
    if ~isempty(x) && max(x) > 0
        xlim(ax, [0, max(x)]);
    end
    style_ax(ax, 'Forecast vs Measured', 'Time (s)', 'Level (m)');
end

function update_xai_plot(ax, features, decision)
% FIX: baselines corrected to realistic initial values to prevent
%      permanent negative bars for peakW and cfar.
%      Order changed to match pro_xai_explainer: SNR,level,vz,cfar,peakW,rate
    cla(ax);
    names = {'SNR','level','vz','cfar','peakW','rate'};
    snr_v  = getf_gui(features,'snr',   15);
    wl_v   = getf_gui(features,'waterLevel', 0.5);
    vz_v   = abs(getf_gui(features,'surfaceVz', 0));
    cf_v   = getf_gui(features,'cfarTargets', 0);
    pw_v   = getf_gui(features,'peakWidth',   0);
    rt_v   = getf_gui(features,'rateOfRise',  0);
    vals   = [snr_v, wl_v, vz_v, cf_v, pw_v, rt_v];
    % Baselines: realistic early-simulation values
    % FIX: cfar baseline=0 (no detections at rest → positive when echo detected)
    %      peakW baseline=0.12m (realistic matched-filter 3dB width)
    base   = [15,  0.5, 0.05, 0,  0.12, 0.0];
    norm_b = max(abs(base), [1, 0.5, 0.01, 1, 0.05, 0.005]);
    w      = [0.15, 0.35, 0.05, 0.10, 0.10, 0.25];
    contrib = w .* ((vals - base) ./ norm_b);
    contrib = max(min(contrib, 1), -1);
    [~,idx] = sort(abs(contrib),'descend');
    colors = repmat([0.55 0.75 1], length(names), 1);
    colors(contrib(idx) < 0, :) = repmat([1 0.45 0.45], sum(contrib(idx)<0), 1);
    bar(ax, contrib(idx), 'FaceColor','flat', 'CData', colors);
    xticks(ax, 1:length(names));
    xticklabels(ax, names(idx));
    yline(ax, 0, '-', 'Color', [0.6 0.6 0.6]);
    style_ax(ax, 'XAI Feature Importance (SHAP-like)', 'Feature', 'Contribution');
end

function v = getf_gui(s,f,def)
    if isstruct(s) && isfield(s,f), v=s.(f); else, v=def; end
end

function update_rangeprofile(ax, rp, params)
    cla(ax);
    r_axis = (1:length(rp)) / params.samplesPerMeter;
    plot(ax, r_axis, abs(rp), '-', 'Color',[0.4 0.95 1], 'LineWidth', 1.5);
    style_ax(ax, 'Range Profile', 'Range (m)', '|signal|');
end

function update_rdmap(ax, rd)
    cla(ax);
    imagesc(ax, 20*log10(abs(rd)+eps));
    colormap(ax, 'jet');
    style_ax(ax, 'Range-Doppler Map (dB)', 'Doppler bin', 'Range bin');
end

function update_cfar_history(ax, mask, t)
    persistent CFARHIST
    if isempty(CFARHIST), CFARHIST = []; end
    CFARHIST = [CFARHIST, double(mask(:))];
    if size(CFARHIST,2) > 200, CFARHIST = CFARHIST(:, end-199:end); end
    cla(ax);
    imagesc(ax, CFARHIST);
    colormap(ax, [0 0 0; 1 0.5 0; 1 1 0]);
    style_ax(ax, 'CFAR Detection History', 'Time tick', 'Range bin');
end

function update_spectrum(ax, sp)
    cla(ax);
    sp = abs(sp(:));
    sp = sp(1:floor(end/2));
    plot(ax, 20*log10(sp+eps), '-', 'Color',[1 0.6 0.4], 'LineWidth', 1.2);
    style_ax(ax, 'Beat Spectrum (dB)', 'Frequency bin', 'dB');
end

function setup_3d(ax, params)
    cla(ax);
    [X,Y] = meshgrid(linspace(-30,30,80), linspace(-15,30,80));
    % V-shaped wadi terrain
    Z = 0.15*abs(X) + 0.03*Y + 0.5*exp(-(X.^2+Y.^2)/400);
    % Save terrain in axes UserData for water update
    surf(ax, X, Y, Z, 'EdgeColor','none', 'FaceColor','interp', ...
        'FaceLighting','gouraud');
    colormap(ax, 'copper');
    hold(ax,'on');
    % Radar tower
    [xc,yc,zc] = cylinder([0.5 0.5], 16);
    surf(ax, xc, yc, zc*params.mountHeight, 'FaceColor',[0.55 0.55 0.6], ...
        'EdgeColor','none');
    plot3(ax, 0, 0, params.mountHeight+1, 'ro', 'MarkerFaceColor','r', ...
        'MarkerSize', 14);
    % Initial water plane
    Zw = max(Z, 0.5);
    hw = surf(ax, X, Y, Zw, 'FaceColor',[0.1 0.55 0.95], ...
        'FaceAlpha', 0.6, 'EdgeColor','none');
    light(ax,'Position',[1 1 1]); light(ax,'Position',[-1 -1 0.5]);
    view(ax, 35, 30); axis(ax, 'tight');
    set(ax,'Color',[0.05 0.07 0.13],'XColor','w','YColor','w','ZColor','w', ...
        'GridColor',[0.3 0.4 0.5],'GridAlpha',0.3);
    grid(ax,'on');
    xlabel(ax,'X (m)','Color','w');
    ylabel(ax,'Y (m)','Color','w');
    zlabel(ax,'Z (m)','Color','w');
    title(ax, '🌊 3D Wadi Digital Twin (rotate with mouse)', ...
        'Color',[1 0.85 0.3],'FontSize',13);
    set(ax,'UserData',struct('X',X,'Y',Y,'Z',Z,'wh',hw));
end

function update_3d_water(ax, level, t, params)
    ud = get(ax, 'UserData');
    if isempty(ud) || ~isfield(ud,'wh'), return; end
    if ~ishandle(ud.wh), return; end
    Zw = max(ud.Z, level);
    % Add ripple effect on water surface
    ripple = 0.04 * sin(2.5*ud.X + 2*t) .* cos(2.5*ud.Y + 2*t);
    flooded = ud.Z < level;
    Zw(flooded) = level + ripple(flooded);
    set(ud.wh, 'ZData', Zw);
    title(ax, sprintf('🌊 Digital Twin · t=%.1fs · Water Level=%.2fm', t, level), ...
        'Color',[1 0.85 0.3],'FontSize',13);
end

function draw_gauge(ax, risk)
    cla(ax);
    risk = max(0, min(1, risk));
    % Background semi-circle
    th = linspace(pi, 0, 100);
    fill(ax, cos(th), sin(th), [0.2 0.25 0.32], 'EdgeColor','none');
    hold(ax,'on');
    % Color zones
    th_g = linspace(pi, pi*0.66, 30); fill(ax, [cos(th_g) 0.66 0], [sin(th_g) 0 0], [0.2 0.7 0.3], 'EdgeColor','none');
    th_y = linspace(pi*0.66, pi*0.33, 30); fill(ax, [cos(th_y) 0.33 0.66], [sin(th_y) 0 0], [1 0.85 0.2], 'EdgeColor','none');
    th_r = linspace(pi*0.33, 0, 30); fill(ax, [cos(th_r) 1 0.33], [sin(th_r) 0 0], [0.95 0.2 0.25], 'EdgeColor','none');
    % Center cover
    fill(ax, 0.7*cos(th), 0.7*sin(th), [0.13 0.16 0.22], 'EdgeColor','none');
    % Needle
    ang = pi - risk * pi;
    plot(ax, [0 0.85*cos(ang)], [0 0.85*sin(ang)], '-', 'Color',[1 1 1], 'LineWidth', 4);
    plot(ax, 0, 0, 'o', 'MarkerFaceColor','w', 'MarkerSize', 12);
    % Text
    text(ax, 0, -0.2, sprintf('%.0f%%', risk*100), ...
        'HorizontalAlignment','center', 'FontSize', 30, 'FontWeight','bold', ...
        'Color',[1 1 1]);
    text(ax, -1, -0.05, 'SAFE', 'Color',[0.5 1 0.5], 'FontSize', 10);
    text(ax, 0.85, -0.05, 'CRITICAL', 'Color',[1 0.4 0.4], 'FontSize', 10);
    axis(ax, 'equal'); axis(ax, 'off');
    xlim(ax, [-1.2 1.2]); ylim(ax, [-0.4 1.2]);
end

function score = update_anomaly(features, state)
    % Simple z-score anomaly
    x = [features.waterLevel; features.rateOfRise; features.snr/20; features.peakWidth];
    if state.n == 0
        score = 0;
    else
        z = (x - state.mu) ./ (state.sigma + 1e-6);
        score = min(1, sqrt(mean(z.^2)) / 5);
    end
end
