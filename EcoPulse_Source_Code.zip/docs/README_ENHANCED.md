# Rahma Radar – Enhanced Flood Monitoring System

This folder contains the **professional-grade** version of the flood-monitoring
radar simulator, with every enhancement from the specification document
implemented across **21 MATLAB files + 1 JSON config**.

## Quick Start

```matlab
% 1) Default scenario (slow_rise)
main_flood_monitoring_system

% 2) Custom scenario via helper
params = get_params('fast_rise');
results = main_flood_monitoring_system_core(params);
dashboard_philip(results, params);
animate_flood_3d(results, params);

% 3) Load from JSON
params = get_params('config_default.json');

% 4) Monte-Carlo evaluation
params = get_params();
params.mc_runs = 20;
main_flood_monitoring_system   % will run MC automatically

% 5) Interactive GUI (uifigure + tabs)
params = get_params();
params.use_gui = true;
main_flood_monitoring_system
```

## File Map

| File | Purpose | Status |
|------|---------|--------|
| `get_params.m` | All parameters, scenarios, feature switches | **Enhanced** |
| `config_loader.m` | JSON / YAML config loader | **New** |
| `config_default.json` | Default external config | **New** |
| `signal_generation.m` | Carrier, agility, Barker/Frank, multi-burst, window choice | **Enhanced** |
| `environment_model.m` | P-M/Elfouhaily waves, Doppler, bank MP, colored noise, rain | **Enhanced** |
| `signal_processing.m` | Range-Doppler, CFAR, eigen-SNR, MUSIC/ESPRIT | **Enhanced** |
| `cfar_detector.m` | CA-CFAR & OS-CFAR | **New** |
| `kalman_tracker.m` | Constant-velocity Kalman filter for water level | **New** |
| `music_esprit.m` | Sub-space super-resolution range estimator | **New** |
| `matrix_handler.m` | Higher-order MTI, auto-save, auto-reshape | **Enhanced** |
| `feature_extraction.m` | Kalman, Doppler, peak-width, CFAR-count features | **Enhanced** |
| `decision_logic.m` | ARIMA/linear forecast, ML-classifier hook, risk prob | **Enhanced** |
| `arima_predictor.m` | ARIMA(1,1,1) or linear-regression forecaster | **New** |
| `ml_classifier.m` | SVM-like logistic classifier (file-loadable) | **New** |
| `alarm_validation.m` | Persistence + countdown + forecast fields | **Enhanced** |
| `weather_model.m` | CSV or synthetic wind & rain vs time | **New** |
| `ray_tracing.m` | Simplified wadi-wall multipath (image method) | **New** |
| `myConvFFT.m` | Fast FFT convolution | Same |
| `dashboard_philip.m` | Tabbed dashboard + R-D + stats + ROC + export | **Enhanced** |
| `animate_flood_3d.m` | STL tower, fog, big digital indicators, wave rose, countdown | **Enhanced** |
| `flood_gui.m` | uifigure-based GUI with tabs | **New** |
| `run_monte_carlo.m` | MC driver for Pd / Pfa / ROC | **New** |
| `export_report.m` | PDF report via Report Generator or exportgraphics | **New** |
| `main_flood_monitoring_system.m` | Top-level driver (supports MC, GUI) | **Enhanced** |
| `main_flood_monitoring_system_core.m` | Single-run worker function | **New** |

## Implemented Enhancement Features

### 1. Signal Generation (Bemwa)
- ✅ Carrier frequency support (`enable_passband`, `f0 = 24 GHz`)
- ✅ Frequency-agility (pulse-to-pulse hopping via `freq_hop_set`)
- ✅ Selectable window: `hann` / `kaiser` / `chebwin` / `taylorwin`
- ✅ Multi-burst generation with configurable gaps
- ✅ Barker (lengths 2,3,4,5,7,11,13) & Frank (M²) phase codes

### 2. Environment Model (Abdelmonem)
- ✅ Pierson-Moskowitz **and** Elfouhaily-like wave spectra
- ✅ Doppler phase shift from surface vertical velocity
- ✅ Bank reflections (`bank_multipath`)
- ✅ Colored noise (AR-1) alternative to AWGN
- ✅ ITU-R style rain attenuation (`rain_rate_mmph`)
- ✅ Simplified ray-tracing hook (`raytracing = true`)

### 3. Signal Processing (Menna)
- ✅ Range-Doppler 2-D FFT map
- ✅ CFAR detection (CA & OS) with user-defined Pfa
- ✅ Kalman filter water-level tracking (constant-velocity model)
- ✅ Eigenvalue-based SNR estimation
- ✅ Higher-order MTI cancellers (1/2/3, via `params.mti_order`)
- ✅ MUSIC / ESPRIT super-resolution range estimation

### 4. Decision Logic (Rahma)
- ✅ ARIMA(1,1,1) if Econometrics Toolbox available, else linear prediction
- ✅ Pluggable ML classifier (file loader in `ml_classifier.m`)
- ✅ Risk-probability output (`decision.riskProb`)

### 5. Matrix Handling (Menna)
- ✅ Automatic `.mat` save at end of simulation
- ✅ 2nd / 3rd order MTI
- ✅ Auto-reshape when range-bin count changes

### 6. Visualisation (Philip)
- ✅ Tabbed dashboard (Core / Advanced / Stats)
- ✅ Range-Doppler heatmap panel
- ✅ Risk-probability curve panel
- ✅ ROC curve panel (from Monte-Carlo)
- ✅ Countdown timer annotation
- ✅ Export-to-PDF button & `export_report.m`
- ✅ Wave-direction rose (polaraxes)
- ✅ 3D fog / haze overlay
- ✅ Big digital indicators (level + status)
- ✅ STL-radar tower loader (if `tower.stl` available)
- ✅ Full GUI via `flood_gui.m` (uifigure + tabs)

### 7. Parameter & Integration (Kareem / All)
- ✅ JSON config (`config_default.json` + `config_loader.m`)
- ✅ Five pre-defined scenarios: `stable`, `slow_rise`, `fast_rise`, `receding`, `flash_flood`
- ✅ Monte-Carlo driver (`run_monte_carlo.m`)
- ✅ Weather integration (`weather_model.m` + optional CSV)
- ✅ Simplified ray-tracing (`ray_tracing.m`)

## Backward Compatibility

The original API is preserved:

- `signal_generation(mode, params)` → still `[tx_signal, tx_matrix]` (third meta arg is optional)
- `environment_model(tx_signal, params, t)` → still `[rx_signal, meta]`
- `signal_processing(tx, rx, params, meta)` → still returns `proc.range_profile`, etc.
- `feature_extraction(proc, prevLevel, params, meta)` → works without Kalman arg
- `alarm_validation(decision, history, params)` → same output fields + new `timeRemaining`
- `dashboard_philip(results, params)` → same signature

## Scenarios

```matlab
params = get_params('stable');       % water level = 0.5 m
params = get_params('slow_rise');    % +0.025 m/s (original default)
params = get_params('fast_rise');    % +0.08 m/s
params = get_params('receding');     % -0.015 m/s
params = get_params('flash_flood');  % sigmoidal rise
```

## Troubleshooting

| Symptom | Fix |
|---------|------|
| `chebwin` missing | Signal Processing Toolbox not installed → `window_type = 'hann'` |
| `arima` missing | Econometrics Toolbox not installed → falls back to linear regression automatically |
| `uifigure` missing | Using an older MATLAB release → `params.use_gui = false` uses `dashboard_philip` |
| `exportgraphics` missing | Fallback saves PNGs instead of a PDF |
| `stl_radar_file` missing | `use_stl_radar = false` (default) draws a simple box tower |
| MATLAB Report Generator missing | `export_report.m` auto-falls back to multi-page PDF via `exportgraphics` |

## License

Educational / research use. Credits to the original Rahma team
(Rahma, Menna, Bemwa, Abdelmonem, Philip, Kareem).
