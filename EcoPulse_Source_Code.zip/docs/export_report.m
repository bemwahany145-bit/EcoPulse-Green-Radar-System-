function export_report(results, params, figList)
% EXPORT_REPORT  Save all open figures + summary to a PDF report.
%
% Usage:
%   export_report(results, params, [fig1, fig2]);
%
% Falls back to concatenating PNGs into a single PDF if the MATLAB Report
% Generator is not available.

    if nargin<3, figList = findall(0,'Type','figure'); end
    outfile = getfield_or(params,'report_file','flood_report.pdf');

    try
        % Preferred: Report Generator
        if exist('mlreportgen.report.Report','class')==8
            rpt = mlreportgen.report.Report(outfile,'pdf');
            tp  = mlreportgen.report.TitlePage;
            tp.Title    = 'Flood Monitoring Radar Report';
            tp.Subtitle = sprintf('Scenario: %s  | Final Status: %s', ...
                getfield_or(params,'scenario','?'), ...
                getfield_or(results,'finalStatus','?'));
            tp.Author   = 'Radar Team';
            tp.PubDate  = datestr(now,'dd-mmm-yyyy HH:MM');
            add(rpt,tp);
            for i=1:numel(figList)
                f = mlreportgen.report.Figure(figList(i));
                add(rpt,f);
            end
            close(rpt); rptview(rpt);
            fprintf('[export_report] saved -> %s\n', outfile); return;
        end
    catch ME
        warning('Report Generator failed: %s -> using PDF fallback', ME.message);
    end

    % Fallback: exportgraphics to multi-page PDF
    try
        if exist('exportgraphics','file')
            if isfile(outfile), delete(outfile); end
            for i=1:numel(figList)
                exportgraphics(figList(i), outfile, 'Append', true);
            end
            fprintf('[export_report] saved -> %s (exportgraphics)\n', outfile);
        else
            for i=1:numel(figList)
                saveas(figList(i), sprintf('flood_report_%d.png', i));
            end
            fprintf('[export_report] saved as PNGs (no exportgraphics available)\n');
        end
    catch ME
        warning('export_report failed: %s', ME.message);
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
