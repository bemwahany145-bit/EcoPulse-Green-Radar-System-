# 🌊 EcoPulse: 24 GHz FMCW Radar Flash Flood Early-Warning System

**EcoPulse** is an advanced end-to-end MATLAB/Octave simulation platform for a 24 GHz FMCW (Frequency Modulated Continuous Wave) radar system designed for early detection and monitoring of flash floods. Developed for the **IEEE AESS Sustainability Hackathon 2026**, this project provides a robust, toolbox-free solution for real-time water level monitoring, risk assessment, and automated alerting.

---

## 🚀 Key Features

- **High-Precision Radar Simulation**: Full FMCW signal chain including waveform synthesis, propagation, clutter modeling, and super-resolution processing.
- **Interactive 3D Digital Twin**: Real-time visualization of wadi surfaces and rising water levels with dynamic ripple effects.
- **Advanced Decision Fusion**: Combines ARIMA forecasting, LSTM-style neural predictors, Fuzzy Logic risk assessment, and Sequential Bayes (SPRT).
- **Sustainability & Resilience**: Includes solar energy management simulations, tamper-evident blockchain logging, and edge-AI deployment modules.
- **Multi-Platform Support**: Fully compatible with MATLAB R2018b+ and GNU Octave 7+, requiring no external toolboxes.

---

## 📁 Repository Structure

```text
EcoPulse/
├── RUN.m                   # Main entry point / Launcher
├── config/                 # Configuration files
│   └── config_default.json # System parameters in JSON
├── docs/                   # Documentation and reports
│   ├── README_ULTIMATE.md  # Detailed module documentation
│   └── export_report.m     # PDF report generation
├── src/
│   ├── core/               # Radar signal processing & environment models
│   ├── gui/                # Interactive dashboards & 3D visualizations
│   └── pro/                # Advanced enhancement modules (AI, Blockchain, etc.)
├── tests/                  # Performance evaluation & Monte Carlo simulations
└── README.md               # This file
```

---

## ⚡ Quick Start

1. **Clone the repository**:
   ```bash
   git clone https://github.com/[your-username]/EcoPulse.git
   cd EcoPulse
   ```

2. **Run in MATLAB/Octave**:
   Open MATLAB or Octave in the project root and execute:
   ```matlab
   >> RUN
   ```
   This will initialize the environment and launch the **Ultimate GUI Dashboard**.

---

## 📊 Technical Core

- **FMCW Radar**: 24 GHz center frequency, optimized for environmental sensing.
- **Signal Processing**: Matched filtering, CA/OS-CFAR detection, and MUSIC/ESPRIT super-resolution.
- **Risk Assessment**: Mamdani fuzzy inference system coupled with Bayesian sequential testing.
- **Green Tech**: Integrated solar harvest modeling and low-power mode logic.

---

## 📜 Credits & License

- **Project**: EcoPulse (Rahma Radar Ultimate v4)
- **Competition**: IEEE AESS Sustainability Hackathon 2026
- **License**: MIT License (or as specified in the project documentation)

---

*Developed with a focus on environmental sustainability and disaster resilience.*
