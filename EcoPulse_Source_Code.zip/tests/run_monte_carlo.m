function mc = run_monte_carlo(paramsBase, nRuns)
% RUN_MONTE_CARLO  Evaluate detection probability (Pd) and false-alarm
% probability (Pfa) across many independent runs with random noise seeds.
%
%   mc = run_monte_carlo(params, 20);
%
% It repeatedly invokes main_flood_monitoring_system_core.m (single-run
% worker) and accumulates alarm-confirmation statistics.

    if nargin<2, nRuns = 20; end
    if nargin<1, paramsBase = get_params(); end

    % scenarios: alternate flood & stable for Pd/Pfa
    Pd_list  = false(nRuns,1);
    Pfa_list = false(nRuns,1);

    for i = 1:nRuns
        rng(paramsBase.mc_seed_base + i);
        p = paramsBase; p.mc_runs = 0;    % avoid recursion
        if mod(i,2)==0
            p.scenario = 'fast_rise';
            truth = 1;
        else
            p.scenario = 'stable';
            truth = 0;
        end
        res = main_flood_monitoring_system_core(p);

        alarm = ~strcmp(res.finalStatus,'monitoring');
        if truth==1, Pd_list(i)  = alarm;
        else,        Pfa_list(i) = alarm;
        end
        fprintf('[MC] run %d/%d  scenario=%s  final=%s  alarm=%d\n', ...
                i, nRuns, p.scenario, res.finalStatus, alarm);
    end

    mc.nRuns = nRuns;
    mc.Pd    = mean(Pd_list(1:2:end));
    mc.Pfa   = mean(Pfa_list(2:2:end));

    % simple ROC by varying persistenceWindow
    wins = [10 30 60 90 120];
    mc.roc.Pd = zeros(size(wins));
    mc.roc.Pfa = zeros(size(wins));
    for w=1:length(wins)
        p = paramsBase; p.mc_runs = 0; p.persistenceWindow = wins(w);
        % approximate: rerun only 4 trials per threshold for speed
        pd = 0; pfa = 0;
        for i=1:4
            rng(paramsBase.mc_seed_base + 1000 + i);
            p.scenario = 'fast_rise';
            res = main_flood_monitoring_system_core(p);
            pd = pd + ~strcmp(res.finalStatus,'monitoring');
            p.scenario = 'stable';
            res = main_flood_monitoring_system_core(p);
            pfa = pfa + ~strcmp(res.finalStatus,'monitoring');
        end
        mc.roc.Pd(w)  = pd/4;
        mc.roc.Pfa(w) = pfa/4;
    end

    fprintf('[MC] Summary: Pd=%.2f Pfa=%.2f\n', mc.Pd, mc.Pfa);
end
